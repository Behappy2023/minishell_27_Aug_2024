
#include "../minishell.h"




void	ft_exit_from_exec(char *s1,char *s2, char *s3 ,int type_exit, t_data *d)
{
	(void)d;
	(void)s1;
	(void)s3;

	// char	**sp_cmd;
	// sp_cmd 	= ft_split(s2, ' ');

	// ft_exec_error_is_dollar(sp_cmd[0], d);
	// printf("%s%s%s\n", s1, sp_cmd[0], s3);
	printf("%s%s%s\n", s1, s2, s3);
	if(g%3==0)printf("		type exit in exit from exec(child) = %d	(65 exec.c)\n", type_exit);
	// ft_free_2split(sp_cmd, NULL, d);
	d->exit_stat = type_exit;
	if(g%3==0)printf("\033[0;31m		exit=%d\033[0m (68 exec.c)\n",d->exit_stat);
	
	
	// if (d->shell_level < 1 )
	// {
					// ft_free_list(d->head);
					// ft_free_split_input(d->sp_input);
					// free(d->input);


		int		exit_status_no_free = d->exit_stat;

		ft_close_fd(d);
		ft_free_system(d);
		// if (d->env)
		// 	ft_env_free_array(d->env);		// <===============
		ft_free_system_2(d);
	/*
		rl_clear_history();
		// ft_free_set_start(d);
		free(d->word_real);				// ft_free_set_start
		free(d->word_tmp );				// ft_free_set_start
		ft_env_free_array(d->env);		// <================


		ft_env_free_list(d->env_list);	// ft_free_set_start
		int		exit_status_no_free = d->exit_stat;
		free(d);
	*/
		exit(exit_status_no_free);
	// }
}






// void	ft_free_2split(char **sp_path, char **sp_cmd, t_data *d)
// {
// 	int	i;
// 	(void)d;

// 	i = 0;
// 	while (sp_path[i])
// 	{
// 		free(sp_path[i]);
// 		i++;
// 	}
// 	free(sp_path);
// 	i = 0;
// 	while (sp_cmd[i])
// 	{
// 		free(sp_cmd[i]);
// 		i++;
// 	}
// 	free(sp_cmd);
// 	// free(d);  // <======= sure??
// }


char	*ft_find_path(char **env)
{
	char	*s;
	int		i;
	int		j;

	s = "PATH=";
	i = 0;
	j = 0;
	while (env[i])
	{
		j = 0;
		while (s[j] == env[i][j])
		{
			if (j == 4)
				return (&env[i][j + 1]);
			j++;
		}
		i++;
	}
	return (NULL);
}


int	ft_is_cmd(char *cmd, char **env, t_data *d)
{
	char	**sp_cmd;
	char	**sp_path;
	int		i;
	char	*tmp;
	char	*path_cmd;

	sp_cmd 	= ft_split(cmd, ' ');
	sp_path = ft_split(ft_find_path(env), ':');

	i = 0;
	while (sp_path[i])
	{
		tmp = ft_strjoin(sp_path[i], "/");
		path_cmd = ft_strjoin(tmp, sp_cmd[0]);
		free(tmp);
		if (access(path_cmd, X_OK) == 0)
		{
			//free !!!///<< ========
			// free(path_cmd);						//wrong
			// ft_free_2split(sp_path, sp_cmd, d);	//wrong
			free(path_cmd);
			ft_free_2split(sp_path, sp_cmd, d);

			return(1);
			// execve(path_cmd, sp_cmd, env);
		}
		free(path_cmd);
		i++;
	}
	ft_free_2split(sp_path, sp_cmd, d);
	// ft_exit_from_exec("command \'", cmd, "\' not found", 127, d);
	ft_exit_from_exec("", 		cmd, ": command not found", 127, d);
	return(0);
}


void	ft_exec(char *cmd, char **env, t_data *d)
{
	char	**sp_cmd;
	char	**sp_path;
	int		i;
	char	*tmp;
	char	*path_cmd;

	sp_cmd 	= ft_split(cmd, ' ');
	sp_path = ft_split(ft_find_path(env), ':');

	i = 0;
	while (sp_path[i])
	{
		tmp = ft_strjoin(sp_path[i], "/");
		path_cmd = ft_strjoin(tmp, sp_cmd[0]);// /home/kdanchal/bin  /  ls
		free(tmp);
		if (access(path_cmd, X_OK) == 0)
		{
			execve(path_cmd, sp_cmd, env);
		}
		free(path_cmd);
		i++;
	}
	ft_free_2split(sp_path, sp_cmd, d);
	// ft_exit_from_exec("command \'", cmd, "\' not found", 127, d);  ///<=== what ?
	ft_exit_from_exec("", 		cmd, ": command not found", 127, d);


}




int		ft_cmd_have_path(char *cmd)
{
	// printf("		chk_path	(128 exec.c)\n");

	if (ft_strchr(cmd, '/'))
	{
		if(g%2==0)printf("		have_path	(132 exec.c)\n");
		return(1);
	}
	else
	{	
		if(g%2==0)printf("		no_path	(137 exec.c)\n");   //aaaa <=====
		return(0);
	}
}

void	ft_exec_have_path(char *cmd, char **env, t_data *d)
{
	char	**sp_cmd_real_real;
	char	**sp_slash;
	char	**sp_path;
	int		i;
// 	char	*tmp;
// 	char	*path_cmd;

	sp_slash 	= ft_split(cmd, '/');
	sp_path = ft_split(cmd, ' ');

	// sp_path = ft_split(ft_find_path(env), ':');

	i = 0;
	while(sp_slash[i])
	{
		if (g%2==0)printf("	sp_slash[%d]	= %s	(195)\n", i, sp_slash[i]);
		i++;
	}
	sp_cmd_real_real = ft_split(sp_slash[i - 1], ' ');

	// i = 0;
	// while(sp_cmd_real_real[i])
	// {
	// 	printf("%s	(202)\n", sp_cmd_real_real[i]);
	// 	i++;
	// }

	// while (sp_path[i])
	// {
	// 	tmp = ft_strjoin(sp_path[i], "/");
	// 	path_cmd = ft_strjoin(tmp, sp_cmd[0]);// /home/kdanchal/bin  /  ls
	// 	free(tmp);

		if (g%2==0)printf("	sp_path[0] 	= %s	(214 exec.c)\n" ,sp_path[0]);
		if (g%2==0)printf("	sp_slash[i-1]	= %s	(215 exec.c)\n" ,sp_slash[i -1]);

		if (access(sp_path[0], X_OK) == 0)
		{
			if(g%2==0)printf("		before execve	(160 exec.c)");
			// execve(cmd, &sp_cmd[i], env);
			execve(sp_path[0], sp_cmd_real_real, env);
		}
/*
		if (access(cmd, X_OK) == 0)
		{
			if(g%2==0)printf("		before execve	(160 exec.c)");
			// execve(cmd, &sp_cmd[i], env);
			execve(cmd, sp_cmd_real_real, env);
		}
*/
		// free(path_cmd);
		// i++;
	// }

	// ft_free_split(sp_path);
	// ft_free_2split(sp_cmd_real_real, sp_slash, d);
	ft_free_3split(sp_path, sp_cmd_real_real, sp_slash, d);

	// ft_exit_from_exec("command \'", cmd, "\' not found", 127, d);
	ft_exit_from_exec("", 		cmd, ": command not found", 127, d);

}



char **ft_convert_env_list_to_array(t_env *env_list)
{
    // นับจำนวนโหนดในลิงค์ลิสต์
    int count = 0;
    t_env *current = env_list;
    while (current) 
    {
        count++;
        current = current->next;
    }

    // สร้างอาร์เรย์ของสตริง
    char **env_array = (char **)malloc((count + 1) * sizeof(char *));
    if (!env_array) 
    {
        perror("malloc");
        return NULL;
    }

    // คัดลอกค่าจากลิงค์ลิสต์ไปยังอาร์เรย์ของสตริง
    current = env_list;
    int i = 0;
    while (i < count) 
    {
        int name_len = strlen(current->name);
        int value_len = strlen(current->value);
        env_array[i] = (char *)malloc((name_len + value_len + 2) * sizeof(char)); // +2 สำหรับ '=' และ '\0'
        if (!env_array[i]) 
        {
            perror("malloc");
            while (i > 0) 
            {
                i--;
                free(env_array[i]);
            }
            free(env_array);
            return NULL;
        }
        sprintf(env_array[i], "%s=%s", current->name, current->value); // sprintf
        current = current->next;
        i++;
    }

    // จบอาร์เรย์ของสตริงด้วย NULL
    env_array[count] = NULL;

    return env_array;
}

// void ft_env_free_array(char **env_array)
// {
//     if (!env_array) 
//     {
//         return;
//     }
    
//     int i = 0;
//     while (env_array[i]) 
//     {
//         free(env_array[i]);
//         i++;
//     }
//     free(env_array);
// }


void ft_env_free_array(char **env_array) 
{
    int i = 0;

    // ตรวจสอบว่า env_array ไม่ใช่ NULL
    if (!env_array) 
	{
        return;
    }

    // ปล่อยหน่วยความจำของแต่ละสตริงในอาร์เรย์
    while (env_array[i]) 
	{
        free(env_array[i]);
        i++;
    }

    // ปล่อยหน่วยความจำของอาร์เรย์เอง
    free(env_array);
}
