#include "../minishell.h"


void	ft_exec_system(t_data *d)
{
	    if (!d->input)
		{
			return;
		}
		// if (d->error_syntax == 1)  //===>ft_set_status
		// {
		// 	if(g%2==0)printf("	syntax error_ft_exec_system (267 main.c)\n");
		// 	// ft_free_list(d->head);
		// 	// ft_free_split_input(d->sp_input);
		// 	// free(d->input);
		// 	d->exit_stat =512;
		// 	return;
		// }
		
		// d->save_env_list = d->env_list;
		d->current = d->head;
		d->history_pipe = 0;
		d->exit_stat = ft_connect2(d, d->current);
		if(g%3==0)printf("	d->exit_status=%d	(303 main.c)\n",d->exit_stat);
}
 