
#include "../minishell.h"


void	ft_child_check_error_open_file(t_data *d)
{
		if (d->error_open_file_in_normal == 2 && d->error_first_open_will_show == 1)
			ft_exit_from_exec("bash: ", d->file_in_first_name, ": No such file or directory",1 ,d);
			// ft_exit_from_exec("bash: ", d->error_file_in_normal_name, ": No such file or directory",1 ,d);
		
		else if (d->error_open_file_in_normal == 1 && d->error_first_open_will_show == 2)
			ft_exit_from_exec("bash: ", d->file_in_first_name, ": Permission denied",1 ,d);
			// ft_exit_from_exec("bash: ", d->error_file_in_normal_name, ": Permission denied",1 ,d);
	

		else if (d->error_open_file_out_trunc == 2 && d->error_first_open_will_show == 3)
			ft_exit_from_exec("bash: ", d->file_out_first_name, ": No such file or directory",1 ,d);
			// ft_exit_from_exec("bash: ", d->error_file_out_trunc_name, ": No such file or directory",1 ,d);
		else if (d->error_open_file_out_trunc == 1 && d->error_first_open_will_show == 4)
		{
			if (access(d->file_out_first_name, F_OK) == -1) 
				ft_exit_from_exec("bash: ", d->file_out_first_name, ": No such file or directory",1 ,d);
			else
				ft_exit_from_exec("bash: ", d->file_out_first_name, ": Permission denied",1 ,d);
			// ft_exit_from_exec("bash: ", d->error_file_out_trunc_name, ": Permission denied",1 ,d);
		}


		else if (d->error_open_file_out_append == 2 && d->error_first_open_will_show == 5)
			ft_exit_from_exec("bash: ", d->file_out_first_name, ": No such file or directory",1 ,d);
			// ft_exit_from_exec("bash: ", d->error_file_out_append_name, ": No such file or directory",1 ,d);

		else if (d->error_open_file_out_append == 1 && d->error_first_open_will_show == 6) // <===check
		{
			if (access(d->file_out_first_name, F_OK) == -1) 
				ft_exit_from_exec("bash: ", d->file_out_first_name, ": No such file or directory",1 ,d);
			else
				ft_exit_from_exec("bash: ", d->file_out_first_name, ": Permission denied",1 ,d);
			// ft_exit_from_exec("bash: ", d->error_file_out_append_name, ": Permission denied",1 ,d);
		}
		return;
}


void	ft_child_child(t_data *d) // mj_cnp
{
	int		exit_status_no_free;

	if (ft_is_builtin(d->cmd, d))
	{
		ft_exec_builtin(d->cmd, d, NULL);////
		d->exit_stat = d->exit_stat / 256; 
		if(g%3==0)printf("	%d<===exit_status	(260 connect.c)\n", d->exit_stat);
		
		
		exit_status_no_free = d->exit_stat / 256;
		
		ft_free_system(d);
		ft_free_system_2(d);

		exit (exit_status_no_free);		//<=======1exit
		
		// exit (d->exit_stat);		//<=======1exit
	}
	if(g%3==0)printf("	%d<===exit_status	(227 connect.c)\n", d->exit_stat);
	if(g%2==0)printf("	no_builtin	(165 connect.c)\n");
	
	// ft_env_free_array(d->env);		// <===============

	d->env = ft_convert_env_list_to_array(d->env_list);
	if (ft_cmd_have_path(d->cmd))
		ft_exec_have_path(d->cmd, d->env, d);
	else
	{
		if(g%2==0)printf("	before exec	(171coneect.c)\n");
		ft_exec(d->cmd, d->env, d);
		if(g%2==0)printf("	after exec	(174coneect.c)\n");
	}
}


void	ft_child(t_data *d) // mj_cnp
{
	if(g%2==0)printf("	child	(84 connect.c) \n");

	if (g%2==0)printf("	d->have_symbol_indirect = %d\n	d->cmd = %s	(86 child par)\n", d->have_symbol_indirect, d->cmd);
	if ( (d->have_symbol_indirect == 0) && !ft_is_builtin(d->cmd ,d) && !ft_cmd_have_path(d->cmd)) 
		ft_is_cmd(d->cmd, d->env, d);

	ft_child_check_error_open_file(d);
	close(d->fd_pipe[0]);
	if (d->fd_in != 0)
	{
		dup2(d->fd_in, 0);
		close(d->fd_in);
	}

	if (!ft_is_builtin(d->cmd ,d) && !ft_cmd_have_path(d->cmd)) 
		ft_is_cmd(d->cmd, d->env, d);

	if (d->have_pipe)
	{
		dup2(d->fd_pipe[1], 1);
		// if (d->fd_out != 1)
		// {
		// 	dup2(d->fd_out, 1);
		// 	close(d->fd_out);
		// }
		close(d->fd_pipe[1]);
	}
	if (d->fd_out != 1)
	{
		dup2(d->fd_out, 1);
		close(d->fd_out);
	}
	if(g%2==0)printf("	history_pipe = %d	(210 connect.c)\n", d->history_pipe);
	if(g%2==0)printf("	d->cmd = %s	(211 connect.c)\n", d->cmd);


	ft_child_child(d);

	printf("	===child not close alive now	(244 connect.c)");
}






void	ft_parrent(t_data *d, t_list *current)
{
	if(g%2==0)printf("	Parrent	(180 connect.c)\n");

	close(d->fd_pipe[1]);
	if (d->fd_in != 0)
		close(d->fd_in);
	if (!current || !current->next)
	{
		if (d->fd_out != 1)
			close(d->fd_out);
	}
	else
	{
		dup2(d->fd_pipe[0], 0);
		close(d->fd_pipe[0]);
		// round++;
		if(g%3==0)printf("	===>Before REC d->exit_status =%d	(parrent 270 connect.c)\n", d->exit_stat );
		// ft_connect2(d, current->next);
		d->exit_stat = ft_connect2(d, current->next);
		if(g%3==0)printf("	===>After REC d->exit_status =%d	(parrent 275 connect.c)\n", d->exit_stat );
		// exit(d->exit_status);
	}
}
