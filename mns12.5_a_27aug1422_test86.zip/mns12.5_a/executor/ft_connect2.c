
#include "../minishell.h"

void	ft_set_connect2(t_data *d)
{
	d->error_cmd_null_status = 0;
	d->cmd = NULL;
	d->fd_in = 0;
	d->name_file_in = NULL;
	d->file_in_first_status = 1;
	d->file_in_first_name = NULL;
	d->file_out_before_file_in =1;

	d->fd_out = 1;
	d->name_file_out = NULL;
	d->file_out_first_status = 1;
	d->file_out_first_name = NULL;

	d->have_pipe = 0;
	d->have_symbol_indirect = 0;

	// d->history_pipe = 0; // <== (exit |exit)  vs  (<f1<f6|<f7) 	(<f6)
	// d->save_stdin = dup(0);
	// d->save_stdout = dup(1);

	d->error_open_file_in_normal = 0;
	d->error_file_in_normal_name = NULL;
	d->error_open_file_out_trunc = 0;
	d->error_file_out_trunc_name = NULL;
	d->error_open_file_out_append = 0;
	d->error_file_out_append_name = NULL;

	d->error_open_some_file = 0;
	d->error_first_open_will_show = 0;
}

t_list	*ft_check_file_in_out_cmd_pipe(t_data *d ,t_list *current)
{
	while (current)
	{
		if (g%2==0)printf("	cur con= %s	,cur sym = %d	(41 connect2.c)\n", current->content ,current->symbol);
		if (current->symbol >= 4 && current->symbol <= 7)
			d->have_symbol_indirect = 1;
		if (current->status == 4 && d->error_first_open_will_show == 0) // file <
			d->fd_in = ft_open_file_in_normal(current->content, d);
		else if (current->status == 5 && d->error_first_open_will_show == 0) // file << HRER doc
			d->fd_in = ft_open_file_in_here_doc(current->content, d);
		else if (current->status == 6 && d->error_first_open_will_show == 0) // file > trunc
			d->fd_out = ft_open_file_out_trunc(current->content, d);
		else if (current->status == 7 && d->error_first_open_will_show == 0) // file >> append
			d->fd_out = ft_open_file_out_append(current->content, d);
		else if (current->status == 8)
		{
			d->cmd = current->content;	
			if(g%2==0)printf("	d->cmd		= %s\n", current->content);
		}
		else if (current->symbol == 8)
		{	
			if(g%2==0)printf("	have pipe(%d)\n", current->symbol);
			d->have_pipe = 1;
			d->history_pipe = 1;
			break;
		}
		current = current->next;
	}
	return(current);
}


int	ft_cmd_null(t_data	*d, t_list *current)
{
	if (d->name_file_in)
	{
		// printf("abc\n");
		if (access(d->name_file_in, F_OK) == -1) 
		{
			printf("bash: %s: No such file or directory	 (282 connect)\n", d->name_file_in);
			d->error_cmd_null_status = 1;
		}
		else if (open(d->name_file_in,O_RDONLY, 0644) == -1)
		{
			printf("bash: %s: Permission denied ====>file in	(292 connect)\n", d->name_file_in);
			d->error_cmd_null_status = 1;
		}
	}
	if( (d->name_file_out) && (open(d->name_file_out, O_WRONLY | O_CREAT | O_TRUNC, 0644) == -1))
	{
		printf("bash: %s: Permission denied ===>file out	(301 connect)\n", d->name_file_out);
		d->error_cmd_null_status = 1;
	}				
	


	
	// if (!d->name_file_in && !d->name_file_in )
	// 	return(d->exit_stat);

	// else 
	if (d->history_pipe == 1)
		d->exit_stat = 0;		
	else if ((d->error_cmd_null_status == 1) && (d->history_pipe == 0))
		d->exit_stat = 256;
	// else if ((d->error_cmd_null_status == 0) && (d->history_pipe == 0))
	// 	d->exit_stat = 0;
	if (d->have_pipe)
		d->exit_stat = ft_connect2(d, current->next);
	if(g%3==0){printf("	d->exit_status = ");printf("\033[0;32m%d\033[0m", d->exit_stat);printf(" 	(89 connect2.c)\n\n\n");}
	return(d->exit_stat);


/*
	if ((d->error_cmd_null_status == 1) && (d->history_pipe == 0))
		d->exit_stat = 256;
	if (d->have_pipe)
		d->exit_stat = ft_connect2(d, current->next);
	return(d->exit_stat);
*/
}

int	ft_connect2(t_data *d, t_list *current)
{
	static int	round = 1;
	static int	time = 100000;
	if(g%2==0)printf("\n	===round %d===\n",round);

	ft_set_connect2(d);
	// Save original stdin, stdout
	int save_stdin = dup(0);
	int	save_stdout = dup(1);
	(void)save_stdin ;
	(void)save_stdout ;



	current = ft_check_file_in_out_cmd_pipe(d ,current);
	if(g%2==0)printf("	history_pipe = %d	(302 connect.c)\n", d->history_pipe);

	if (d->cmd == NULL) /////////////////////
		return(ft_cmd_null(d, current));



	if (ft_is_minishell(d->cmd, d))
		d->exit_stat = 0;

	if ((d->have_pipe == 0 )&& ft_is_builtin_set_1(d->cmd, d) && d->history_pipe == 0)	
	{
		// 1cd, 
		// 2export_para(no print), 
		// 3unset , 
		// 4exit , 
		// 5./minishell
		if(g%2==0)printf("	history_pipe = %d	(389 connect.c)\n", d->history_pipe);
		// ft_exec_builtin(d->cmd, d, "export_no_print");
		ft_exec_builtin(d->cmd, d, "");
		
		//free in minishell loop

		if(g%2==0)printf("	history_pipe = %d	(391 connect.c)\n", d->history_pipe);
		return(d->exit_stat);
	}

	else 
	{

		if(g%2==0)printf("	before pipe fork exec	(252 connect.c)\n");

		if (pipe(d->fd_pipe) == -1)
			ft_exit_from_exec("", "", "pipe error", 1, d);

		d->pid = fork(); //<==========================

		if (d->pid == -1)
			ft_exit_from_exec("", "", "fork error", 1, d);

		else if (d->pid == 0)  
		{
			if(g%2==0)printf("	d->cmd = %s	(393 connect.c)\n", d->cmd);

			if(g%2==0)	printf("	time = %d	(176 connect.c)\n", time);
			usleep((time ));
			ft_child(d);				// Child process
		}
		else  
		{	
			round++;
			if (time >= 200) time = time - 200;
			// waitpid(d->pid ,&d->exit_stat, 0);	//<==== wait 2 place

			ft_parrent(d, current);		// Parent process					
			// waitpid(d->pid ,&d->exit_stat, 0);	//<==== wait 2 place
			if (g%2==0) {printf("	(482 connect.c)\n");}
			// wait(NULL);								//<==== wait 2 place

			if(g%3==0) {printf("	before waitpid and /256	d->exit_stat = "); printf("\033[0;32m%d\033[0m", d->exit_stat);  printf("	(343 connect.c)\n"); }
	
			dup2(save_stdin, 0);
			dup2(save_stdout, 1);
			close(save_stdin);
			close(save_stdout);
			time = 900;
			round = 1;
		}

	}

	waitpid(d->pid ,&d->exit_stat, 0);	//<==== wait 2 place

	// wait(NULL);								//<==== wait 2 place
	ft_close_fd(d);

	usleep((time ));

	if(g%3==0)	{printf("	fin process connect2	d->exit_status = "); printf("\033[0;32m%d\033[0m", d->exit_stat); printf("	(473 connect.c)\n"); }
	if(g%5==0)	{printf("	minishell level = ");printf("\033[0;35m%d\033[0m",d->shell_level);printf(" 	(477 connect2.c)\n");}
	return(d->exit_stat);
}					
