
#include "../minishell.h"
/*
32512 - 20 =27392


*/


int	ft_open_file_out_append(char *name_file, t_data *d) //// 0 =in 1 =out 2=heredoc
{
	if ( (d->file_out_before_file_in == 1) ||  ( d->error_open_some_file == 0 ) )
	{
		if (d->fd_out > 1)
			close (d->fd_out);
		d->fd_out = open(name_file, O_WRONLY | O_CREAT | O_APPEND, 0644);
		if (d->fd_out < 0)
		{
			d->error_open_some_file = 1;
			d->error_first_open_will_show = 6;
			
			d->error_open_file_out_append = 1;
			d->error_file_out_append_name = name_file;
			d->name_file_out = name_file;
		}
		if ( (d->file_out_first_status == 1) && d->error_open_some_file > 0 )
		{
			d->name_file_out = name_file;				//  pls chk up or down
			d->file_out_first_name = name_file;		//  pls chk up or down
			d->file_out_first_status = 0;
			if(g%2==0)printf("	d->file_out_first_status (%d)	= %s\n", d->fd_out, d->name_file_out);
		}
		if(g%2==0)printf("	d->fd_out_ap (%d)	= %s\n", d->fd_out, name_file);
	}
	return(d->fd_out);
}



int	ft_open_file_out_trunc(char *name_file, t_data *d) //// 0 =in 1 =out 2=heredoc
{
	if ( (d->file_out_before_file_in == 1) || ( d->error_open_some_file == 0 ) )
	{
		if (d->fd_out > 1)
			close (d->fd_out);
		d->fd_out = open(name_file, O_WRONLY | O_CREAT | O_TRUNC, 0644);
		if (d->fd_out < 0)
		{
			d->error_open_some_file = 1;
			d->error_first_open_will_show = 4;

			d->error_open_file_out_trunc = 1;
			d->error_file_out_trunc_name = name_file;
			d->name_file_out = name_file;
		}
		if ( (d->file_out_first_status == 1) && d->error_open_some_file > 0 )
		{
			d->name_file_out = name_file;				//  pls chk up or down
			d->file_out_first_name = name_file;		//  pls chk up or down
			d->file_out_first_status = 0;
			if(g%2==0)printf("	d->file_out_first_status (%d)	= %s\n", d->fd_out, d->name_file_out);
		}
		if(g%2==0)printf("	d->fd_out_tr (%d)	= %s\n", d->fd_out, name_file);
	}
	return(d->fd_out);
}


int	ft_open_file_in_here_doc(char *content_stop_word, t_data *d)
{
	// int	nb_fd;
	// nb_fd = 0;

	d->file_out_before_file_in = 0;
	if (d->fd_in)
		close (d->fd_in);

	if(g%2==0)printf("	Here doc Zone!!	(38 connect.c)\n");
	d->word_stop = content_stop_word;
	d->word_real = NULL;

	ft_handle_signals_for_here_doc();  //<==================== signal !!!

	if(g%2==0)printf("	d->stop_word=%s	(40 connect.c)\n",d->word_stop);
	while(1)
	{
		d->word_add =readline("> ");

		if (ft_strcmp(d->word_add, d->word_stop) == 0)
		{
			free(d->word_add);
			break; 
		}
		if (d->word_real)
		{
			char *tmp = ft_strjoin(d->word_real, "\n");
			free(d->word_real);
			d->word_real = ft_strjoin(tmp, d->word_add);
			free(tmp);
		}
		else
			d->word_real = ft_strdup(d->word_add);


		free(d->word_tmp);	
	}
	


	// Create a pipe for heredoc input
	int fd_heredoc[2];
	if (pipe(fd_heredoc) == -1) 
	{
		perror("pipe");
		if(g%3==0)printf("\033[0;31m	exit=%d\033[0m (93 open_file.c)",d->exit_stat);
		exit(EXIT_FAILURE);
	}

	write(fd_heredoc[1], d->word_real, ft_strlen(d->word_real));
	write (fd_heredoc[1], "\n", 1);
	close(fd_heredoc[1]);
	// d->fd_in = fd_heredoc[0];
	d->fd_in = fd_heredoc[0];

	free(d->word_real);


	if ( (d->file_in_first_status == 1) && d->error_open_some_file > 0 )
	{
		d->name_file_in = content_stop_word;
		d->file_in_first_status = 0;
	}
	if(g%2==0)printf("	d->fd_in  (%d)	= HERE_DOC\n", d->fd_in);




	return(d->fd_in);
}


void	ft_open_file_in_normal_2(char *name_file, t_data *d)
{
	d->name_file_in = name_file;				//  pls chk up or down
	d->file_in_first_name = name_file;		//  pls chk up or down
	d->file_in_first_status = 0;
	if(g%2==0)printf("	d->file_in_first_status (%d)	= %s\n", d->fd_in, d->name_file_in);
}

int	ft_open_file_in_normal(char *name_file, t_data *d)
{
	d->file_out_before_file_in = 0;
	if (d->fd_in)
		close (d->fd_in);
	if (access(name_file, F_OK) == -1) 
	{
		d->error_open_some_file = 1;
		d->error_first_open_will_show = 1;
		d->error_open_file_in_normal = 2;  // no_file ==>error=2
		d->error_file_in_normal_name = name_file;
	}
	else
	{
		d->fd_in = open(name_file, O_RDONLY, 0644);
		if (d->fd_in < 0)
		{
			d->error_open_some_file = 1;
			d->error_first_open_will_show = 2;
			d->error_open_file_in_normal = 1; // have file but permis not read  ==>error=1
			d->error_file_in_normal_name = name_file;
		}
	}
	if ( (d->file_in_first_status == 1) && d->error_open_some_file > 0 )
		ft_open_file_in_normal_2(name_file, d);

	if(g%2==0)printf("	d->fd_in  (%d)	= %s\n", d->fd_in, name_file);
	return(d->fd_in);
}
