/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_super_split_1.c                                 :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: kwangtip <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/08/12 14:48:57 by kwangtip          #+#    #+#             */
/*   Updated: 2024/08/12 14:48:59 by kwangtip         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */


#include "../minishell.h"

t_split	ft_isset(t_split *sp)
{

	if (sp->ib > 0)
	{
		sp->buf[sp->ib] = '\0';
   		sp->tokens = ft_realloc(sp->tokens, sp->it * sizeof (char *), 
                	(sp->it + 1) * sizeof(char *));
   		// sp->tokens = realloc(sp->tokens, sp->it * sizeof (char *), 
        //         	(sp->it + 1) * sizeof(char *));
   		sp->tokens[sp->it++] = ft_strdup(sp->buf);
    	sp->ib = 0;

	}

	// sp->tokens = realloc(sp->tokens, sp->it * sizeof (char *),(sp->it + 1) * sizeof(char *));
	sp->tokens = ft_realloc(sp->tokens, sp->it * sizeof (char *),(sp->it + 1) * sizeof(char *));
    sp->tokens[sp->it] = NULL;
	return(*sp); 
}

void	*ft_realloc(void *ptr, size_t old_size, size_t new_size)
{
	void	*new_ptr;

	new_ptr = malloc(new_size);
	// ft_memset(&new_ptr, 0, new_size);
	if (!new_ptr)
	{
		free(ptr);
		return (NULL);
	}
	// new_ptr = NULL;
	// ft_memset(&new_ptr, 0, sizeof(new_size));
	// new_ptr = ""; //<===add
	// new_ptr = ft_strdup("");
	// new_ptr = NULL;

	if (ptr)
	{
		if (old_size < new_size)
		{
			// memcpy(new_ptr, ptr, old_size);
			ft_memcpy(new_ptr, ptr, old_size);
		}
		else
		{
			// memcpy(new_ptr, ptr, new_size);
			ft_memcpy(new_ptr, ptr, new_size);
		}
		free(ptr);
	}
	return (new_ptr);

	// (void)ptr;
	// (void)old_size;
	// (void)new_size;
	// return(ptr);
}

t_split ft_isheredoc_appen(char *str, t_split *sp)
{
    if(sp->ib > 0)
    {
        sp->buf[sp->ib] = '\0';
        sp->tokens = ft_realloc(sp->tokens, sp->it * sizeof (char *), 
                        (sp->it + 1) * sizeof(char *));
        sp->tokens[sp->it++] = ft_strdup(sp->buf);
        sp->ib = 0;
    }
    sp->buf[sp->ib ++] = *str++;
    sp->buf[sp->ib ++] = *str++;
    sp->buf[sp->ib] = '\0';
    sp->tokens = ft_realloc(sp->tokens, sp->it * sizeof (char *), 
                (sp->it + 1) * sizeof(char *));
    sp->tokens[sp->it++] = ft_strdup(sp->buf);
    sp->ib = 0;

	return(*sp);
}

int ft_inquote(char *str, t_split *sp)
{
    sp->buf[sp->ib++] = *str;
     if (*str == sp->quote)
    {
        sp->iq = 0;
        sp->quote = 0;
    }
	str++;
	return(sp->iq); 
}

// void	ft_set_super_split(t_split *sp)
// {
// 	sp->tokens=NULL;
// 	// sp->buf=NULL;
// 	memset(sp->buf, 0, sizeof(sp->buf));
// 	sp->quote='\0';
// 	sp->ib=0;
// 	sp->it=0;
// 	sp->iq=0;
// }

char **ft_super_split(char *str, const char *check)
{
    t_split sp;

	// ft_set_super_split(&sp);
    ft_memset(&sp, 0, sizeof(t_split));
    while(*str != '\0')
    {
        if(sp.iq)
            sp.iq = ft_inquote(str++, &sp);
        else
		{
            if (((*str == '<') && *(str + 1) == '<') || (*str == '>' && *(str + 1) == '>'))
            {  
				ft_isheredoc_appen(str, &sp);
				str = str + 2;
			}

			else
				ft_is_type_of_tokens(str++, check, &sp);
		}
     }

	ft_isset(&sp);
    return(sp.tokens);
}
