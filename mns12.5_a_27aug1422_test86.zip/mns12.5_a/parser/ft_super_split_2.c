/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_super_spilit.c                                  :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: kwangtip <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/08/05 15:28:12 by kwangtip          #+#    #+#             */
/*   Updated: 2024/08/05 15:28:14 by kwangtip         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../minishell.h"

t_split ft_skip_space(t_split *sp)
{
    if (sp->ib > 0)
    {
    	sp->buf[sp->ib] = '\0';
        sp->tokens = ft_realloc(sp->tokens, sp->it * sizeof (char *), 
                    (sp->it + 1) * sizeof(char *));
        sp->tokens[sp->it++] = ft_strdup(sp->buf);
        sp->ib = 0;             
    }	
	return(*sp);
}

int		ft_isspace(char *str)
{
	if (*str == '\t' || *str == '\n' || *str == '\v' || *str == '\f' || *str == '\r'
		|| *str == ' ')
		return (1);
	return (0);
}

t_split ft_ischeck(char *str, t_split *sp)
{
    if (sp->ib > 0)
    {
        sp->buf[sp->ib] = '\0';
        sp->tokens = ft_realloc(sp->tokens, sp->it * sizeof (char *), 
                    (sp->it + 1) * sizeof(char *));
        sp->tokens[sp->it++] = ft_strdup(sp->buf);
        sp->ib = 0;             
    }
    sp->buf[sp->ib ++] = *str++;
    sp->buf[sp->ib] = '\0';
    sp->tokens = ft_realloc(sp->tokens, sp->it * sizeof (char *), 
                (sp->it + 1) * sizeof(char *));
    sp->tokens[sp->it++] = ft_strdup(sp->buf);
    sp->ib = 0;
	return(*sp);              
}

int ft_found_quote(char *str,t_split *sp)
{
    sp->iq  = 1;
    sp->quote = *str;
    sp->buf[sp->ib++] = *str++;
	return(sp->iq); 
}

t_split	ft_is_type_of_tokens(char *str, const char *check, t_split *sp)
{
	if(*str == '"' || *str == '\'')
    	sp->iq = ft_found_quote(str, sp);
    else if(ft_strchr(check, *str))
		ft_ischeck(str, sp);
    else if (ft_isspace(str))
		ft_skip_space(sp);
    else
    sp->buf[sp->ib++] = *str++;

	return(*sp);
}
