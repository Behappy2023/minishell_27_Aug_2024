#include "../minishell.h"



// char *ft_replace_quotes(const char *str, int mode)  // 1=space    2=non space
char *ft_replace_quotes(char *str, int mode)  // 1=space    2=non space
{
    if (!str)
        return NULL;

    // Allocate memory for the new string (worst case, same length as original)
    char *new_str = malloc(ft_strlen(str) + 1);
    if (!new_str)
        return NULL;

    char *src = (char *)str;
    char *dst = new_str;

    while (*src) 
	{
        if (*src == '"' || *src == '\'') 
		{
            if (mode == 1) 
			{
                *dst = ' '; // Replace with space if mode 1
                dst++;
            }
            // Skip if mode 2 (no action needed)
        } else 
		{
            *dst = *src; // Copy the character
            dst++;
        }
        src++;
    }

    *dst = '\0'; // Null-terminate the new string
	free(str);
    return new_str;
}



void	ft_set_symbol(t_list **head)
{
	t_list	*current;

	(void)head;
	current = *head;
	while (current)
	{
		// printf("%s\n", current->content);
		// if (current->content[0] == '"')
	/*	
		if (ft_strchr(current->content, '"'))
		{
			// current->content = ft_replace_quotes(current->content , 2);
			current->symbol = 1;
			current->status = 8;
		}
		// else if (current->content[0] == '\'')
		else if (ft_strchr(current->content, '\''))
		{
			// current->content = ft_replace_quotes(current->content , 2);
			current->symbol = 2;
			current->status = 8;
		}
	*/
		// else 
		if (current->content[0] == '$')
		{
			current->symbol = 3;
			current->status = 8;
		}
		else if (ft_strcmp(current->content, "<") == 0)
		{
			current->symbol = 4;
			current->status = 0;
		}
		else if (ft_strcmp(current->content, "<<") == 0)
		{
			current->symbol = 5;
			current->status = 0;
		}
		else if (ft_strcmp(current->content, ">") == 0)
		{
			current->symbol = 6;
			current->status = 0;
		}
		else if (ft_strcmp(current->content, ">>") == 0)
		{
			current->symbol = 7;
			current->status = 0;
		}
		else if (current->content[0] == '|')
		{
			current->symbol = 8;
			current->status = 0;
		}
		else
		{
			current->symbol = 0;
			current->status = 0;
		}
		current = current->next;
	}
}


/*



*/

void	ft_check_error_syntax(t_list **head, t_data *d)
{
	t_list	*current;

	(void)head;
	current = *head;
	(void)current;

	current = *head;
	d->error_syntax = 0;
	while (current && (d->error_syntax == 0))
	{
		if (current->next && (d->error_syntax == 0))
		{
			if (current->next->next && current->next->next->content)
			{
				if (g%2 ==0)printf("	(203 set_symbol_status.c)\n");
			}
			if (current->symbol && (current->status == 0)
				&& current->next->symbol && (current->next->status == 0)
				&& (d->error_syntax == 0))
			{
				if (g%2 ==0)printf("	(140 set_symbol_status.c)\n");
				if (current->next->next && current->next->next->content)
				{
					if (g%2 ==0)printf("	(143 set_symbol_status.c)\n");
					if ((current->next->next->symbol)
						&& (current->next->next->status == 0))
					{
						if (g%2 ==0)printf("    (147 set_symbol_status.c)\n");
						d->exit_stat = 2;
						d->error_syntax = 1;
						if (current->symbol == 8)
							printf("bash: syntax error near unexpected token `%s'    (146 set_symbol_status.c)\n",
								current->content);
						else if (current->symbol != 8)
							printf("bash: syntax error near unexpected token `%s'    (148 set_symbol_status.c)\n",
								current->next->content);
						else
							printf("what??");
					}
				}
				else
				{
					if (g%2 ==0)printf("    (170 set_symbol_status))\n");
					d->exit_stat = 2;
					d->error_syntax = 1;
					if (current->symbol == 8)
						printf("bash: syntax error near unexpected token `%s'    (165 set_sybol_status)\n",
							current->content);
					else if (current->symbol != 8)
						printf("bash: syntax error near unexpected token `%s'    (167 set_sybol_status)\n",
							current->next->content);
					else
						printf("what?? (180 set_symbol_status)");
				}
			}
		}
		else if (!current->next && current->symbol == 8 && current->status == 0)
		{
			d->error_syntax = 1;
			printf("bash: syntax error near unexpected token `%s'	(217  set_symbol_status.c)\n", current->content);
		}
		else if (!current->next && current->symbol && current->status == 0)
		{
			d->error_syntax = 1;	
			printf("bash: syntax error near unexpected token `newline'	(219  set_symbol_status.c)\n");
		}

		current = current->next;
	}
}


void	ft_set_status(t_list **head, t_data *d)
{


	if(g%2==0)ft_print_list(d, "=====before set ft status====="); //

	t_list	*current;
	int		has_builtin;
	int		has_cmd;
	int		has_grep;


	(void)has_builtin;
	(void)has_grep;
	has_builtin = 0;
	has_cmd = 0;
	has_grep = 0;
	(void)d;
	// (void)head;
	current = *head;
	// (void)current;
	while (current)
	{
		if(g%2==0)printf("	cur->content = %s	(294 set sy st)\n", current->content);


		if (ft_is_builtin_for_set_status(current->content, d))
		{
			if(g%2==0)printf("	has builtin = 1	(301 set sy st.c)\n");
			has_builtin = 1;
		}


		if (ft_strcmp (current->content,"grep") == 0)
		{
			if(g%2==0)printf("	has grep = 1	(217 set sy st.c)\n");
			has_grep = 1;
		}


		// if (has_grep == 1)
		// {

		// }
		// else 
		
		if (has_builtin == 1)
		// if (ft_is_builtin_for_set_status(current->content, d))
		{
			if(g%2==0)printf("	has  builtin = 1	(297 set sy st)\n");
			// if (ft_is_echo(current->content, d))
			// {
			// 	if(g%2==0)printf("	has echo = 1	(292 set sy st.c)\n");
			// 	has_builtin = 1;
			// }

			if (current->symbol == 0 || current->symbol == 1 || current->symbol == 2)
			{
				if(g%2==0)printf("	cur->sy = 0 1 2	(298 set sy st.c)\n");

				// if (current->prev->symbol >= 3 && current->prev->symbol >= 7 )
				if (current->prev)
				{

					// current->content = ft_replace_quotes(current->content, 2); ///<=== add work??

					if  (current->prev->symbol >=4 && current->prev->symbol <= 7)  
					// if ( (current->prev->symbol >=4 && current->prev->symbol <= 7)  
					// 	|| ft_strcmp(current->prev->content, "grep")	)
					{
						current->content = ft_replace_quotes(current->content, 2); /////
					}

					if (current->prev->symbol == 3)
					{
						if(g%2==0)printf("	cur->p->sy3 will set st4	(303 set sy st.c)\n");

						current->status = 8;
					}
					else if (current->prev->symbol == 4)
					{
						// current->content = ft_trim_quotes(current->content);
						current->status = 4;
					}
					else if (current->prev->symbol == 5)
						current->status = 5;
					else if (current->prev->symbol == 6)
						current->status = 6;
					else if (current->prev->symbol == 7)
						current->status = 7;
					// else
					// 	current->status = 8;
					/*		
					if (current->next)
					{
						printf("	cur->next	(321 set sy st.c)\n");
						current = current->next;
					}
					else 
					{
						printf("	break	(325 set sy st.c)\n");
						break;
					}
					*/
				}
				
				// else if (ft_is_echo(current->content, d))
				if (current->status  == 0 )
				{
					if ( has_builtin == 1 && current->status != 4 && current->status != 5 && current->status != 6 && current->status != 7)
					{
						if(g%2==0)printf("	has echo=1 && cu_st !=3456 will set st8	(328 set sy st.c)\n");
						// current->content = ft_replace_quotes(current->content, 2); /////		
						if (has_grep == 1)
							current->content = ft_replace_quotes(current->content, 2); /////	
						current->status = 8;

						// has_cmd = 1;	// why not

					}
					else if (has_cmd == 0)
					{
						if(g%2==0)printf("	has cmd=0 will set st8	(340 set sy st.c)\n");
						// current->content = ft_replace_quotes(current->content, 2); /////		
						if (has_grep == 1)
							current->content = ft_replace_quotes(current->content, 2); /////			
						current->status = 8;
						has_cmd = 1;

					}
					
					else if (current->content[0] == '-')
					{
						if(g%2==0)printf("	found - set st8	(351 set sy st.c)\n");
						// current->content = ft_replace_quotes(current->content, 2); /////
						if (has_grep == 1)
							current->content = ft_replace_quotes(current->content, 2); /////	
						current->status = 8;
					}
					else
					{
						if(g%2==0)printf("	set st4	(328 set sy st.c)\n");
						// current->content = ft_replace_quotes(current->content, 2); /////
						if (has_grep == 1)
							current->content = ft_replace_quotes(current->content, 2); /////	

						current->status = 4;
					}
				}
			}
		}
		// else if (ft_strncmp(current->content, "grep ") == 0)
		// {
			
		// }
	////////////////////////////////////////////
		else
		{
			if(g%2==0)printf("	no echo	(374 set sy st)\n");
			if (current->symbol == 0)
			{
				if (current->prev)
				{

					if (current->prev->symbol >=4 && current->prev->symbol <= 7)
						current->content = ft_replace_quotes(current->content, 2);

					if(g%2==0)printf("		(378 set sy st)\n");
					if (current->prev->symbol == 3)
						current->status = 8;
					else if (current->prev->symbol == 4)
						current->status = 4;
					else if (current->prev->symbol == 5)
						current->status = 5;
					else if (current->prev->symbol == 6)
						current->status = 6;
					else if (current->prev->symbol == 7)
						current->status = 7;
					// else if (current->prev->symbol == 1)
					// 	current->status = 8;
					// else if (current->prev->symbol == 2)
					// 	current->status = 8;
					
					else if (has_cmd == 0)
					{
						if(g%2==0)printf("	has cmd=0 will set st8	(421 set sy st.c)\n");
						current->content = ft_replace_quotes(current->content, 2); ////
						current->status = 8;
						has_cmd = 1;

					}
					
					else if (current->content[0] == '-' || current->content[1] == '-')
					{
						if(g%2==0)printf("	found - set st8	(429 set sy st.c)\n");
						current->content = ft_replace_quotes(current->content , 2); /////////////////
						current->status = 8;
					}
					else
					{
						if(g%2==0)printf("	set st4	(434 set sy st.c)\n");
						current->content = ft_replace_quotes(current->content,2);
						current->status = 4;
					}

					// else
					// 	current->status = 8;
				}
				else // for first
				{
					current->content = ft_replace_quotes(current->content,2);
					current->status = 8;
					has_cmd = 1;
				}

			}
		}

		if (current->symbol == 8)
		{
			// has_builtin = 0;
			has_cmd = 0;
			has_builtin = 0;
			has_grep = 0;
		}

		if(g%2==0)printf("		(410 set sy st)\n");

		current = current->next;
	}
}



void	ft_set_symbol_status(t_list **head, t_data *d)
{
	(void)d;
	ft_set_symbol(head);
	ft_set_status(head, d);
	ft_check_error_syntax(head, d);
}
