#include "../minishell.h"


#include <stdio.h>

// int ft_is_error_syntax(char *str)
// {
//     int i = 0;
//     int in_quote = 0; // 0 = no quote, 1 = single quote, 2 = double quote

//     while (str[i])
//     {
//         // ตรวจสอบว่าอยู่ในเครื่องหมายคำพูดหรือไม่
//         if (str[i] == '"' && in_quote != 1)
//             in_quote = in_quote == 0 ? 2 : 0;
//         else if (str[i] == '\'' && in_quote != 2)
//             in_quote = in_quote == 0 ? 1 : 0;

//         // ตรวจสอบสัญลักษณ์ | นอกเครื่องหมายคำพูด
//         if (str[i] == '|' && in_quote == 0)
//         {
//             // ตรวจสอบสัญลักษณ์ | ในตำแหน่งแรกของสตริง
//             if (i == 0)
//                 return 1;
            
//             // ตรวจสอบสัญลักษณ์ | ที่ไม่มีข้อความหลังจากนั้น
//             if (str[i + 1] == '\0' || str[i + 1] == ' ' || str[i + 1] == '\t')
//                 return 1;
//         }

//         i++;
//     }

//     return 0; // ไม่มีข้อผิดพลาดทางไวยากรณ์
// }

// int ft_is_error_syntax(char *str)
// {
//     int i = 0;
//     int in_quote = 0; // 0 = no quote, 1 = single quote, 2 = double quote

//     while (str[i])
//     {
//         // ตรวจสอบว่าอยู่ในเครื่องหมายคำพูดหรือไม่
//         if (str[i] == '"')
//         {
//             if (in_quote != 1) // ไม่ได้อยู่ใน single quote
//             {
//                 if (in_quote == 0) // ไม่ได้อยู่ใน quote ใด ๆ
//                     in_quote = 2; // เริ่ม double quote
//                 else if (in_quote == 2) // อยู่ใน double quote
//                     in_quote = 0; // จบ double quote
//             }
//         }
//         else if (str[i] == '\'')
//         {
//             if (in_quote != 2) // ไม่ได้อยู่ใน double quote
//             {
//                 if (in_quote == 0) // ไม่ได้อยู่ใน quote ใด ๆ
//                     in_quote = 1; // เริ่ม single quote
//                 else if (in_quote == 1) // อยู่ใน single quote
//                     in_quote = 0; // จบ single quote
//             }
//         }
//         // ตรวจสอบสัญลักษณ์ | นอกเครื่องหมายคำพูด
//         if (str[i] == '|' && in_quote == 0)
//         {
//             // ตรวจสอบสัญลักษณ์ | ในตำแหน่งแรกของสตริง
//             if (i == 0)
//                 return 1;   
//             // ตรวจสอบสัญลักษณ์ | ที่ไม่มีข้อความหลังจากนั้น
//             if (str[i + 1] == '\0' || str[i + 1] == ' ' || str[i + 1] == '\t')
//                 return 1;
//         }
//         i++;
//     }
//     return 0; // ไม่มีข้อผิดพลาดทางไวยากรณ์
// }



int ft_is_one_quotes(char *str)
{
    int single_quote_is_one= 0;
	int	single_quote_focus_now =2;
    int double_quote_is_one = 0;
    int double_quote_focus_now = 2;

    while (*str)
    {
        if ((*str == '\'') && (single_quote_focus_now %2 == 0) )
		{
            single_quote_is_one = !single_quote_is_one;
			double_quote_focus_now++;
		}
		else if ((*str == '"')&& (double_quote_focus_now %2 == 0) )
        {
		   double_quote_is_one = !double_quote_is_one;
		   single_quote_focus_now++;
		}
		str++;
    }

    if (single_quote_is_one || double_quote_is_one)
    {
		if(g%2==0)printf("	single or double quote is one in loop	(214 main.c)\n");
        // fprintf(stderr, "Error: Unmatched quote found.\n");
		return (1);
	    // exit(EXIT_FAILURE);
    }
	if(g%2==0)printf("	out loop	(214 main.c)\n");
	return(0);
}


char	*ft_chk_signal_chk_one_quotes(t_data *d)
{
	if (!d->input)
	{
		d->shell_level--;
		if(g%2==0)printf("	ctrl +d  ==>pls ft_free before exit(113 main.c)\n");
		printf("exit\n");
		if(g%3==0)printf("\033[0;31m	exit=%d\033[0m (168 main.c)",0);
		if (d->shell_level < 1 )
		{		
			// ft_free_system(d); // don 't no list no sp_input
			// free(d->input);
			// ft_free_system(d);
			ft_free_system_2(d);

			// rl_clear_history();
			// free(d->word_real);				// ft_free_set_start
			// free(d->word_tmp );				// ft_free_set_start
			// ft_env_free_list(d->env_list);	// ft_free_set_start
			// free(d);
			exit(0);
		}
		return ("no_input==>return to minishell loop");	
	}

	// if (ft_is_one_quotes(d->input) || ft_is_error_syntax(d->input))	
	if (ft_is_one_quotes(d->input))	
	{
		printf("Error_syntax quotes	(147 main.c)\n");
		d->exit_stat = 256;
		if(g%3==0)printf("\033[0;31m	exit=%d\033[0m (175 main.c)\n",d->exit_stat);
		free(d->input);

		// ft_free_system(d);
		// ft_free_system_2(d);
		d->input = NULL;
		return ("no_close quotes==>return to minishell loop");	
	}
	return(0);	
}


void	ft_parser_system(t_data *d)
{
		int	i = 0;
		(void)i;
		(void)d;
		if(g%5==0)printf("\033[0;36m%d-\033[0m",d->shell_level);


		// printf("\033[0;34m%s@%s:~",d->user ,d->table);
		printf("\033[0;34m%s", ft_strchr(d->pwd,'e') + 10);
		d->input = readline("\033[0;33m\033[1m$$$$$$$$$ \033[0m");

		// d->input = readline("\033[0;36mミニシェル ミニヘル ミニヘルプ: \033[0m");
		// int fd = open(d->av[1], O_RDONLY);
		// d->input = get_next_line(fd);

		if (ft_chk_signal_chk_one_quotes(d))
			return;


		if (ft_strlen(d->input) > 0 && ft_strncmp(d->input, "echo" ,4) != 0)
		{
			// printf("bef set exit=%d	(235 main.c)\n",d->exit_stat);
			d->exit_stat = 0;
			// printf("aft set exit=%d	(237 main.c)\n",d->exit_stat);

		}



		add_history(d->input);
		// printf("\n=====test %d===\n",d->exit_stat);
		// if (ft_strlen(d->input) == 0)
		// 	printf("\n=====test+++ %d===\n",d->exit_stat);


		d->sp_input = ft_super_split(d->input, "|&;<>");
		// d->sp_input = ft_split_input(d->input, "|&;<>");
		d->head = NULL;
		while (d->sp_input[i])
		{
			ft_list_add_back(&d->head, d->sp_input[i]); 
			i++;
		}
		ft_set_symbol_status(&d->head, d);
		if(g%2==0)ft_print_list(d, "=====first str====="); //
		ft_merge_status_8(&d->head);
		if(g%2==0)ft_print_list(d, "=====after merge8====="); //



		
}
