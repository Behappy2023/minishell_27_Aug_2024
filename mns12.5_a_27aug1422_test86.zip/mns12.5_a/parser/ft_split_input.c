#include "../minishell.h"

// void	ft_free_split_input(char **tokens)
// {
// 	int i = 0;

// 	while (tokens[i])
// 	{
// 		free(tokens[i]);
// 		i++;
// 	}
// 	free(tokens);
// }




// void *ft_realloc_old(void *ptr, size_t old_size, size_t new_size) 
// {
//     void *new_ptr = malloc(new_size);
//     if (!new_ptr) {
//         free(ptr);
//         return NULL;
//     }
//     ft_memset(new_ptr, 0, new_size);
//     if (ptr) 
// 	{
//         if (old_size < new_size)
//             ft_memcpy(new_ptr, ptr, old_size);
//         else
//             ft_memcpy(new_ptr, ptr, new_size);
//         free(ptr);
//     }
//     return new_ptr;
// }





char	**ft_split_input(char *str, const char *check)
{
	char	**tokens;
	char	buf[1024];
	int		buf_index;
	int		num_tokens;
	int		in_quotes;
	char	quote_char;

	tokens = NULL;
	buf_index = 0;
	num_tokens = 0;
	in_quotes = 0;
	quote_char = 0;
	while (*str)
	{
		if (in_quotes)
		{
			buf[buf_index++] = *str;
			if (*str == quote_char)
			{
				in_quotes = 0;
				quote_char = 0;
			}
			str++;
		}
		else
		{
			if (*str == '"' || *str == '\'')
			{
				in_quotes = 1;
				quote_char = *str;
				buf[buf_index++] = *str++;
			}
			else if ((*str == '<' && *(str + 1) == '<') || (*str == '>' && *(str + 1) == '>'))
			{
				if (buf_index > 0)
				{
					buf[buf_index] = '\0';
					tokens = ft_realloc(tokens, num_tokens * sizeof(char *),
							(num_tokens + 1) * sizeof(char *));
					tokens[num_tokens++] = ft_strdup(buf);
					buf_index = 0;
				}
				buf[buf_index++] = *str++;
				buf[buf_index++] = *str++;
				buf[buf_index] = '\0';
				tokens = ft_realloc(tokens, num_tokens * sizeof(char *),
						(num_tokens + 1) * sizeof(char *));
				tokens[num_tokens++] = ft_strdup(buf);
				buf_index = 0;
			}
			else if (strchr(check, *str))
			{
				if (buf_index > 0)
				{
					buf[buf_index] = '\0';
					tokens = ft_realloc(tokens, num_tokens * sizeof(char *),
							(num_tokens + 1) * sizeof(char *));
					tokens[num_tokens++] = ft_strdup(buf);
					buf_index = 0;
				}
				buf[buf_index++] = *str++;
				buf[buf_index] = '\0';
				tokens = ft_realloc(tokens, num_tokens * sizeof(char *),
						(num_tokens + 1) * sizeof(char *));
				tokens[num_tokens++] = ft_strdup(buf);
				buf_index = 0;
			}
			else if (isspace((unsigned char)*str))
			{
				if (buf_index > 0)
				{
					buf[buf_index] = '\0';
					tokens = ft_realloc(tokens, num_tokens * sizeof(char *),
							(num_tokens + 1) * sizeof(char *));
					tokens[num_tokens++] = ft_strdup(buf);
					buf_index = 0;
				}
				str++;
			}
			else
			{
				buf[buf_index++] = *str++;
			}
		}
	}
	if (buf_index > 0)
	{
		buf[buf_index] = '\0';
		tokens = ft_realloc(tokens, num_tokens * sizeof(char *), (num_tokens + 1) * sizeof(char *));
		tokens[num_tokens++] = ft_strdup(buf);
	}
	tokens = ft_realloc(tokens, num_tokens * sizeof(char *), (num_tokens + 1) * sizeof(char *));
	tokens[num_tokens] = NULL;
	return (tokens);
}
