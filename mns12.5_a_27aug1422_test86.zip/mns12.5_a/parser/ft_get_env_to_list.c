
#include "../minishell.h"

// void ft_env_free_list(t_env *head)
// {
//     t_env *tmp;
//     while (head)
//     {
//         tmp = head;
//         head = head->next;
//         free(tmp->name);
//         free(tmp->value);
//         free(tmp);
//     }
// }


void ft_env_free_list(t_env *env_list)
{
    t_env *temp;

    while (env_list)
    {
        temp = env_list;
        env_list = env_list->next;

        if (temp->name)
            free(temp->name);
        if (temp->value)
            free(temp->value);

        free(temp);
    }
}


t_env *ft_env_list_new(char *name, char *value)
{
    t_env *new_node = (t_env *)malloc(sizeof(t_env));
    if (!new_node)
        return NULL;

    new_node->name = ft_strdup(name);
    new_node->value = ft_strdup(value);
    new_node->status = 0;
    new_node->env_shlvl = 1;
    new_node->high_level = 1; //<===

    new_node->next = NULL;

    return new_node;
}


void ft_env_list_add_back(t_env **head, char *name, char *value)
{
    t_env *new_node = ft_env_list_new(name, value);
    if (!new_node)
        return;

    new_node->next = *head;
    *head = new_node;
}




t_env *ft_env_get_to_list(char **env, t_data *d)
{
    t_env *head = NULL;
    char *name;
    char *value;
	char *tmp1;
	char *tmp2;
	// char *tmp3;
	(void)tmp1;
	(void)tmp2;
	(void)d;
	// (void)tmp3;

    int i = 0;
    while (env[i])
    {
        char *equal_sign = ft_strchr(env[i], '=');
        if (equal_sign)
        {
            *equal_sign = '\0';
            name = env[i];
            value = equal_sign + 1;
			// if (ft_strcmp(name , "SESSION_MANAGER") == 0)
			// {
			// 	tmp1 = ft_strchr ((equal_sign + 1) , '/') + 1;
			// 	tmp2 = ft_strchr ((equal_sign + 1) , '.');
			// 	d->table = ft_strndup_g( tmp1, (tmp2 - tmp1));
			// 	if (g%2==0) printf("	d->table = %s	(86 get_env_to_list.c)\n",d->table);
			// }
			// if (ft_strcmp(name , "USER") == 0)
			// {
			// 	d->user = ft_strdup(value);
			// 	if (g%2==0) printf("	d->user = %s	(100 get_env_to_list.c)\n",d->user);
			// }
			ft_env_list_add_back(&head, name, value);
            *equal_sign = '=';
        }
        i++;
    }

    return head;
}
