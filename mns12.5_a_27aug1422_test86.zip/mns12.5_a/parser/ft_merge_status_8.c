#include "../minishell.h"



char *ft_strjoin_space(char const *s1, char const *s2)
{
    char    *str;
    size_t  len1;
    size_t  len2;

    if (!s1 || !s2)
        return (NULL);
    len1 = strlen(s1);
    len2 = strlen(s2);
    str = malloc(sizeof(char) * (len1 + len2 + 2));
    if (!str)
        return (NULL);
    strcpy(str, s1);
    str[len1] = ' ';
    strcpy(str + len1 + 1, s2);
    return (str);
}

char *ft_strjoin_no_space(char const *s1, char const *s2)
{
    char    *str;
    size_t  len1;
    size_t  len2;

    if (!s1 || !s2)
        return (NULL);
    len1 = strlen(s1);
    len2 = strlen(s2);
    str = malloc(sizeof(char) * (len1 + len2 + 1));
    if (!str)
        return (NULL);
    strcpy(str, s1);
    strcpy(str + len1, s2);
    return (str);
}


void    ft_merge_status_8_original(t_list **head)
{
    t_list  *current = *head;
    t_list  *new_node = NULL;
    t_list  *prev = NULL;
    char    *merged_content = NULL;
    char    *temp;

    while (current)
    {
        if (current->status == 8)
        {
			/*
            if (access(current->content, F_OK) == 0) // Check if file exists
            {
                if (merged_content)
                {
                    new_node = (t_list *)malloc(sizeof(t_list));
                    new_node->content = merged_content;
                    new_node->status = 8;
                    new_node->symbol = 0;
                    new_node->next = current;
                    new_node->prev = prev;
                    if (prev)
                        prev->next = new_node;
                    else
                        *head = new_node;
                    if (current)
                        current->prev = new_node;
                    merged_content = NULL;
                    prev = new_node;
                }
                current->status = 4;
                prev = current;
                current = current->next;
            }
            else
            {
			*/
                if (!merged_content)
                    merged_content = strdup(current->content);
                else
                {
                    temp = ft_strjoin_space(merged_content, current->content);
                    free(merged_content);
                    merged_content = temp;
                }
                t_list *to_free = current;
                current = current->next;
                if (prev)
                    prev->next = current;
                else
                    *head = current;
                if (current)
                    current->prev = prev;
                free(to_free->content);
                free(to_free);
            //}
        }
        else
        {
            if (merged_content)
            {
                new_node = (t_list *)malloc(sizeof(t_list));
                new_node->content = merged_content;
                new_node->status = 8;
                new_node->symbol = 0;
                new_node->next = current;
                new_node->prev = prev;
                if (prev)
                    prev->next = new_node;
                else
                    *head = new_node;
                if (current)
                    current->prev = new_node;
                merged_content = NULL;
                prev = new_node;
            }
            else
            {
                prev = current;
                current = current->next;
            }
        }
    }
    if (merged_content)
    {
        new_node = (t_list *)malloc(sizeof(t_list));
        new_node->content = merged_content;
        new_node->status = 8;
        new_node->symbol = 0;
        new_node->next = NULL;
        new_node->prev = prev;
        if (prev)
            prev->next = new_node;
        else
            *head = new_node;
    }
}



void    ft_merge_status_8(t_list **head)
{
    t_list  *current = *head;
    t_list  *new_node = NULL;
    t_list  *prev = NULL;
    char    *merged_content = NULL;
    char    *temp;

    while (current)
    {
        if (current->status == 8 && current->symbol != 8)
        {
            if (!merged_content)
                merged_content = strdup(current->content);
            else
            {
                temp = ft_strjoin_space(merged_content, current->content);
                free(merged_content);
                merged_content = temp;
            }

            t_list *to_free = current;
            current = current->next;

            if (prev)
                prev->next = current;
            else
                *head = current;

            if (current)
                current->prev = prev;

            free(to_free->content);
            free(to_free);
        }
        else
        {
            if (current->symbol == 8)
            {
                if (merged_content)
                {
                    new_node = (t_list *)malloc(sizeof(t_list));
                    new_node->content = merged_content;
                    new_node->status = 8;
                    new_node->symbol = 0;
                    new_node->next = current;
                    new_node->prev = prev;

                    if (prev)
                        prev->next = new_node;
                    else
                        *head = new_node;

                    if (current)
                        current->prev = new_node;

                    merged_content = NULL;
                }

                prev = current;
                current = current->next;
            }
            else
            {
                prev = current;
                current = current->next;
            }
        }
    }

    if (merged_content)
    {
        new_node = (t_list *)malloc(sizeof(t_list));
        new_node->content = merged_content;
        new_node->status = 8;
        new_node->symbol = 0;
        new_node->next = NULL;
        new_node->prev = prev;

        if (prev)
            prev->next = new_node;
        else
            *head = new_node;
    }
}
