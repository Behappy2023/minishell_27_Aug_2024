
#include "../minishell.h"

void	ft_free_list(t_list *head)
{
	t_list	*temp;

	while (head)
	{
		temp = head;
		head = head->next;
		free(temp->content);
		free(temp);
	}
}


t_list	*ft_list_new(char *content)
{
	t_list	*new_list;


	new_list = malloc(sizeof(t_list));
	if (!new_list) // ตรวจสอบว่า malloc สำเร็จหรือไม่
		return (NULL);
	ft_memset(new_list, 0, sizeof(t_list));


	if (content) // ตรวจสอบว่ามีการกำหนดค่า content หรือไม่
	{
		new_list->content = ft_strdup(content);
		if (!new_list->content)
        {
            free(new_list);
            return (NULL);
        }

	}
	else
		new_list->content = NULL; // หรือจัดการกับกรณีที่ content เป็น NULL

	new_list->symbol = 0;
	new_list->status = 0;
	new_list->next = NULL;
	new_list->prev = NULL;
	return (new_list);

	// if (new_list)
	// {
	// 	new_list->content = ft_strdup(content);
	// 	new_list->symbol = 0;
	// 	new_list->status = 0;
	// 	new_list->next = NULL;
	// 	new_list->prev = NULL;

	// }
	// return (new_list);
}


void	ft_list_add_back(t_list **head, char *content)
{
	t_list	*new_list;
	t_list	*current;

	new_list = ft_list_new(content);
	if (!new_list)
	{
		fprintf(stderr, "Memory allocation failed\n");
		// printf("\033[0;31m	exit=%d\033[0m (45 list_add_back.c **paser)",d->exit_status);
		exit(EXIT_FAILURE);
	}
	if (!*head)
	{
		*head = new_list;
	}
	else
	{
		current = *head;
		while (current->next)
		{
			current = current->next;
		}
		current->next = new_list;
		new_list->prev = current;
	}
}
