
#include "minishell.h"

/*
		if (d->head)
			printf("1.head\n");
		if (d->sp_input)
			printf("2.sp_input\n");
		if (d->input)
			printf("3.input\n");
		if (d->word_real)
			printf("4.real\n");
		if (d->word_tmp)
			printf("5.tmp\n");
		if (d->env_list)
			printf("6.env_list\n");
		if (d)
			printf("7.d\n");
*/

void 	ft_close_fd_2(t_data *d)
{
	if (d->fd_in != 0)
		close(d->fd_in);
	if (d->fd_out != 1)
		close(d->fd_out);
	if (d->fd_pipe[0])
		close(d->fd_pipe[0]);
	if (d->fd_pipe[1])
		close(d->fd_pipe[1]);

	// close(d->save_stdin);
	// close(d->save_stdout);
}

void 	ft_close_fd(t_data *d)
{
	if (d->fd_in != 0)
		close(d->fd_in);
	if (d->fd_out != 1)
		close(d->fd_out);
	if (d->fd_pipe[0])
		close(d->fd_pipe[0]);
	if (d->fd_pipe[1])
		close(d->fd_pipe[1]);
	// close(d->save_stdin);
	// close(d->save_stdout);
}


void	ft_free_system(t_data *d)
{
	(void)d;
	if (d->head)
		ft_free_list(d->head);
	if (d->sp_input)
		// ft_free_split_input(d->sp_input);
		ft_free_split(d->sp_input);

	if (d->input)
		free(d->input);
}

void	ft_free_system_2(t_data *d)
{
	(void)d;
	rl_clear_history();
	if (d->word_real)
		free(d->word_real);				// ft_free_set_start
	if (d->word_tmp)
		free(d->word_tmp );				// ft_free_set_start
	// if (d->user)
	// 	free(d->user); 
	// if (d->table)
	// 	free(d->table);
		// ft_env_free_array(d->env);		// <======
	
	// if (d->env)
	// {
	// 	printf("chk");
	// 	ft_env_free_array(d->env);		// <================
	// }		
	if (d->env_list)
		ft_env_free_list(d->env_list);	// ft_free_set_start
	if (d)
		free(d);
}


void	ft_free_split(char **sp_xxx)
{
	int	i;

	i = 0;
	while (sp_xxx[i])
	{
		free(sp_xxx[i]);
		i++;
	}
	free(sp_xxx);
}



void	ft_free_2split(char **sp_path, char **sp_cmd, t_data *d)
{
	int	i;
	(void)d;

	i = 0;
	while (sp_path[i])
	{
		free(sp_path[i]);
		i++;
	}
	free(sp_path);
	i = 0;
	while (sp_cmd[i])
	{
		free(sp_cmd[i]);
		i++;
	}
	free(sp_cmd);
	// free(d);  // <======= sure??
}


void	ft_free_3split(char **sp_xx1, char **sp_xx2, char **sp_xx3, t_data *d)
{
	(void)d;
	ft_free_split(sp_xx1);
	ft_free_split(sp_xx2);
	ft_free_split(sp_xx3);
}
