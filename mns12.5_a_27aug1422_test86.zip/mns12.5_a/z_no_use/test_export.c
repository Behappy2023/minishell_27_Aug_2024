#include <stdio.h>
#include <stdlib.h>
#include <string.h>

typedef struct s_env {
    char *name;
    char *value;
    struct s_env *next;
} t_env;


void parse_export_cmd(char *cmd, t_env **env_list) { //ส่งแบบ ไม่มี export สิ
    char *token = strtok(cmd, " "); // แยกตามช่องว่างเพื่อหาคำสั่ง export
    while (token != NULL) {
        char *equal_sign = strchr(token, '=');
        if (equal_sign != NULL) {
            // มีเครื่องหมาย = แสดงว่าเป็นตัวแปร name=value
            *equal_sign = '\0'; // ตัดเครื่องหมาย = ออก
            char *name = token;
            char *value = equal_sign + 1;
            // เช็คว่ามี name ใน env_list หรือไม่
            t_env *current = *env_list;
            while (current != NULL) {
                if (strcmp(current->name, name) == 0) {
                    free(current->value); // ลบค่า value เก่า
                    current->value = strdup(value); // กำหนดค่า value ใหม่
                    break;
                }
                current = current->next;
            }
            if (current == NULL) {
                // ถ้าไม่พบ name ใน env_list ให้เพิ่มเข้าไปใหม่
                t_env *new_node = malloc(sizeof(t_env));
                new_node->name = strdup(name);
                new_node->value = strdup(value);
                new_node->next = NULL;

                // เพิ่มโหนดใหม่เข้าไปที่ท้าย env_list
                if (*env_list == NULL) {
                    *env_list = new_node;
                } else {
                    current = *env_list;
                    while (current->next != NULL) {
                        current = current->next;
                    }
                    current->next = new_node;
                }
            }
        } else {
            // ไม่มีเครื่องหมาย = แสดงว่าเป็นตัวแปร name เท่านั้น
            // เช็คว่ามี name ใน env_list หรือไม่ (ในกรณีนี้ value จะเป็น NULL)
            t_env *current = *env_list;
            while (current != NULL) {
                if (strcmp(current->name, token) == 0) {
                    break; // ไม่ต้องทำอะไรเพราะ name นี้มีอยู่แล้ว
                }
                current = current->next;
            }
            if (current == NULL) {
                // ถ้าไม่พบ name ใน env_list ให้เพิ่มเข้าไปใหม่ (value เป็น NULL)
                t_env *new_node = malloc(sizeof(t_env));
                new_node->name = strdup(token);
                new_node->value = NULL;
                new_node->next = NULL;

                // เพิ่มโหนดใหม่เข้าไปที่ท้าย env_list
                if (*env_list == NULL) {
                    *env_list = new_node;
                } else {
                    current = *env_list;
                    while (current->next != NULL) {
                        current = current->next;
                    }
                    current->next = new_node;
                }
            }
        }
        token = strtok(NULL, " "); // ไปตัด token ถัดไป
    }
}

int main() {
    t_env *env_list = NULL;

    // ตัวอย่างการใช้งานฟังก์ชัน parse_export_cmd
    char cmd[] = "export aa=bb cc";
    parse_export_cmd(cmd, &env_list);

    // พิมพ์ค่าใน linked list ที่ได้
    t_env *current = env_list;
    while (current != NULL) {
        printf("Name: %s, Value: %s\n", current->name, current->value);
        current = current->next;
    }

    return 0;
}
