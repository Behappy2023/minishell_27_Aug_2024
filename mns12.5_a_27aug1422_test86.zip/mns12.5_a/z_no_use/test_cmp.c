#include <stdio.h>

// ฟังก์ชันที่ใช้เปรียบเทียบสตริงสองสตริง
int ft_strncmp(const char *s1, const char *s2, size_t n) {
    size_t i = 0;

    // เปรียบเทียบตัวอักษรแต่ละตัวในสตริง
    while (i < n && (s1[i] || s2[i])) {
        if (s1[i] != s2[i]) {
            return ((unsigned char)s1[i] - (unsigned char)s2[i]);
        }
        i++;
    }

    // ถ้าเท่ากันทุกตัวในขอบเขตที่กำหนด ให้คืนค่า 0
    return 0;
}

// // ฟังก์ชันทดสอบ
// int main() {
//     // char str1[] = "export";
//     // char str2[] = "export";
//     char str2[] = "export as=a_y";
//     char str1[] = "export";

//     size_t n = 6;

//     int result = ft_strncmp(str1, str2, n);
//     if (result == 0) {
//         printf("27--0 equal The first %d characters of the strings are equal.\n", result);
//     } else {
//         printf("29--!=0 The first %d characters of the strings are different.\n", result);
//     }

//     return 0;
// }




int	ft_strcmp(const char *s1, const char *s2)
{
	size_t	i;

	i = 0;
	// if (n == 0)
	// 	return (0);

	while ((s1[i] != '\0' && s2[i] != '\0')
	 && s1[i] == s2[i])
		i++;
	return ((unsigned char)s1[i] - (unsigned char)s2[i]);
}

#include <stdio.h>
#include <string.h>

int	main (void)
{
	printf("\n====test===== \n");
	char arr1[20] = "cd";
	char arr2[20] = "cdd";
	
	printf("%d\n", ft_strncmp(arr1, arr2, 6));
	printf("%d\n",    strncmp(arr1, arr2, 6));

	printf("%d\n", ft_strncmp(arr1, arr2, 0));
	printf("%d\n",    strncmp(arr1, arr2, 0));


	printf("\n====test=====22222 \n");
	char arr3[20] = "cd";
	char arr4[20] = "cdd";
	
	printf("%d\n", ft_strcmp(arr3, arr4));
	printf("%d\n",    strcmp(arr3, arr4));


}
