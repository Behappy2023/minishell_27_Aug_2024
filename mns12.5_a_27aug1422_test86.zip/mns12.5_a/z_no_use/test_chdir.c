#include <unistd.h>
#include <stdio.h>

int main(int argc, char *argv[]) {
    // ประกาศตัวแปรสำหรับเก็บไดเร็กทอรีปัจจุบัน
    char cwd[1024];
	// char*cwd;

    // ตรวจสอบว่ามีการระบุไดเร็กทอรีเป้าหมายหรือไม่
    if (argc != 2) {
        fprintf(stderr, "Usage: %s <directory>\n", argv[0]);
        return 1;
    }

    // รับไดเร็กทอรีปัจจุบันก่อนเปลี่ยน
    if (getcwd(cwd, sizeof(cwd)) != NULL) {
        printf("Current working directory: %s\n", cwd);
    } else {
        perror("getcwd() error");
        return 1;
    }

    // เปลี่ยนไดเร็กทอรีไปยังไดเร็กทอรีที่ระบุใน argv[1]
    if (chdir(argv[1]) != 0) {
        perror("chdir() error");
        return 1;
    }

    // รับไดเร็กทอรีปัจจุบันหลังจากเปลี่ยน
    if (getcwd(cwd, sizeof(cwd)) != NULL) {
        printf("Current working directory after chdir: %s\n", cwd);
    } else {
        perror("getcwd() error after chdir");
        return 1;
    }

    return 0;
}
