


//9223372036854775808



int	main(void)
{
	long long int ma =  9223372036854775807;
	long long int mi = -9223372036854775808;

	long long int a = 0;
	long long int b = 0;
	long long int c = 1;




	a = ( ma  	+ c) 	%256	;
	b = ((mi*-1) + c)	%256	;

	printf(" 807 a=%d\n",a);
	printf("-808 b=%d\n",b);

}
