#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

// ฟังก์ชันที่ใช้ตัดสตริงด้วยตัวอักษรที่กำหนด
char	*ft_strtok(char *str, const char *delim)
{
	char	*token_start;

	static char *next_token = NULL; // ตัวแปรเก็บ state ของฟังก์ชัน
	// ถ้า str ไม่ใช่ NULL กำหนด next_token เป็น str เพื่อเริ่มต้นการตัด
	if (str != NULL)
	{
		next_token = str;
	}
	else if (next_token == NULL)
	{
		return (NULL); // ถ้า next_token เป็น NULL แล้วไม่มีสตริงที่ต้องตัด
	}
	// ข้ามตัวอักษร delimiters ที่อยู่ที่หน้าสุดของ next_token
	while (*next_token && strchr(delim, *next_token))
	{
		next_token++;
	}
	// ถ้า next_token เป็น NULL หรือสตริงว่าง คืนค่า NULL เพื่อจบการตัดสตริง
	if (!*next_token)
	{
		next_token = NULL;
		return (NULL);
	}
	// หาตำแหน่งสุดท้ายของสตริงที่ไม่ใช่ delimiter
	token_start = next_token;
	while (*next_token && !strchr(delim, *next_token))
	{
		next_token++;
	}
	// กำหนด NULL ต่อท้าย token แล้วคืนค่า pointer ไปยัง token
	if (*next_token)
	{
		*next_token = '\0';
		next_token++;
	}
	return (token_start);
}

// ฟังก์ชันทดสอบ
int	main(void)
{
// 	char	str[] = "This is a sample string, with some punctuation.";
// 	char	*token;

// 	const char delim[] = " ,."; // ตัวอักษร delimiters
// 	token = ft_strtok(str, delim);
// 	while (token != NULL)
// 	{
// 		printf("Token: %s\n", token);
// 		token = ft_strtok(NULL, delim);
// 	}
// 	return (0);




char str[] = "Hello, world! Welcome to C programming.";
char *token = ft_strtok(str, " ,!");

while (token != NULL) {
    printf("%s\n", token);
    token = ft_strtok(NULL, " ,!");



}
}
