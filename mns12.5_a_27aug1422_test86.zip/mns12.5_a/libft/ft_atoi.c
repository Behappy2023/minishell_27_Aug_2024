/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_atoi.c                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: kdanchal <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/08/25 18:37:18 by kdanchal          #+#    #+#             */
/*   Updated: 2024/02/14 14:03:13 by kdanchal         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"
#include <stdio.h>

ssize_t	ft_atoi2(const char *str, int i, int isneg)
{
	unsigned long long int	num;

	num = 0;
	while ('0' <= str[i] && str[i] <= '9' )
	{

		num = (num * 10) + (str[i] - '0');
		if ((isneg == 1) && (num > 9223372036854775807))
			return (0);
		if ((isneg == -1)  && ( (num - 1) > 9223372036854775807))
			return (0);
		i++;
	}
	return (num * isneg);
}


ssize_t	ft_atoi(const char *str)
{
	ssize_t	num;
	int				isneg;
	int				i;

	num = 0;
	isneg = 1;
	i = 0;
	while (str[i] == ' ' || str[i] == '\t' || str[i] == '\n'
		|| str[i] == '\r' || str[i] == '\v' || str[i] == '\f')
		i++;
	if (str[i] == '+')
		i++;
	else if (str[i] == '-')
	{
		isneg *= -1;
		i++;
	}
	num = ft_atoi2(str, i, isneg);
	return (num);
}
