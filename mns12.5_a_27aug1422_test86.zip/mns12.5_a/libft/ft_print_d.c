/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_print_d.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: kdanchal <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/11/08 09:53:36 by kdanchal          #+#    #+#             */
/*   Updated: 2024/03/21 10:09:17 by kdanchal         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

int	ft_len_d(int nb)
{
	size_t	len;

	len = 0;
	if (nb < 0)
	{
		len++;
		nb = nb * -1;
	}
	else if (nb == 0)
	{
		return (1);
	}
	while (nb > 0)
	{
		nb = nb / 10;
		len++;
	}
	return (len);
}

int	ft_print_d2(int args)
{
	char	c;
	int		tmp;

	if (args >= 10)
	{
		tmp = ft_print_d2(args / 10);
		if (tmp == -1)
			return (-1);
		c = args % 10 + '0';
		if (write (1, &c, 1) == -1)
			return (-1);
	}
	else
	{
		c = args % 10 + '0';
		if (write (1, &c, 1) == -1)
			return (-1);
	}
	return (1);
}

int	ft_print_d(int args)
{
	int		len;
	int		nb;
	int		tmp;

	if (args == -2147483648)
	{
		if (write(1, "-2147483648", 11) == -1)
			return (-1);
		return (11);
	}
	nb = args;
	if (args < 0)
	{
		if (write(1, "-", 1) == -1)
			return (-1);
		args = args * -1;
	}
	tmp = ft_print_d2(args);
	if (tmp == -1)
		return (-1);
	len = ft_len_d(nb);
	return (len);
}
