/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_atoi.c                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: kdanchal <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/08/25 18:37:18 by kdanchal          #+#    #+#             */
/*   Updated: 2024/02/14 14:03:13 by kdanchal         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"
#include <stdio.h>

// int	ft_inputcorrect(const char *s)
// {
// 	int	i;

// 	i = 0;
// 	if ('+' == s[i] || s[i] == '-')
// 	{
// 		i++;
// 		if (s[i] == '\0')
// 			return (0);
// 	}
// 	while (s)
// 	{
// 		if ('0' <= s[i] && s[i] <= '9')
// 			i++;
// 		else if (s[i] == '\0')
// 			return (1);
// 		else
// 			return (0);
// 	}
// 	return (1);
// }



ssize_t	ft_atoi2(const char *str, int i, int isneg)
// long long int	ft_atoi2(const char *str, int i, int isneg)
{
	unsigned long long int	num;
	// long long int	num;
	// ssize_t	num;

	num = 0;
	while ('0' <= str[i] && str[i] <= '9' )
	{

		num = (num * 10) + (str[i] - '0');
		// if ((num * isneg) > 2147483647 || (num * isneg) < -2147483648)
		// if ((num * isneg) > 9223372036854775807)
		// {
		// 	printf("\n====(54 atoi.c)\n");
		// 	// return (-1);
		// 	return (0);
		// }
		// if ((num * isneg) < (-9223372036854775808))
		// {
		// 	printf("\n====(60 atoi.c)\n");
		// 	return (0);
		// }

		// printf("isneg = %d, num = %llu	(64 atoi)\n", isneg, num);
		if ((isneg == 1) && (num > 9223372036854775807))
		{
			printf("	chk +	(54 atoi.c)\n");
			// return (-1);
			return (0);
		}


		if ( (num - 9223372036854775807) > 1)
		{
			printf("	chk -	(77 atoi.c)	%llu\n", (num - 1)); //9223372036854775807));
		}

		if ((isneg == -1)  && ( (num - 1) > 9223372036854775807))
		{
			printf("	chk -	(82 atoi.c)\n");
			// printf("	chk -	(83 atoi.c)	%llu\n", (num - 1)); //9223372036854775807));

			return (0);
		}
 

		i++;


		// if (isneg == 1 && num > (9223372036854775807LL - (str[i] - '0')) / 10)
		// 	return (-1);  // Overflow จะคืนค่าเป็น -1
		// if (isneg == -1 && num > (9223372036854775807LL - (str[i] - '0')) / 10)
		// 	return (0);  // Underflow จะคืนค่าเป็น 0
		// num = (num * 10) + (str[i] - '0');
		// i++;


	}
	printf("\n	(78 atoi.c)  %lli\n", num * isneg);
	return (num * isneg);
}



/*
		if (isneg == 1 && num > (9223372036854775807LL - (str[i] - '0')) / 10)
			return (-1);  // Overflow จะคืนค่าเป็น -1
		if (isneg == -1 && num > (9223372036854775807LL - (str[i] - '0')) / 10)
			return (0);  // Underflow จะคืนค่าเป็น 0
		num = (num * 10) + (str[i] - '0');
		i++;
*/

ssize_t	ft_atoi(const char *str)
// long long int	ft_atoi(const char *str)
{
	printf("\n	go_to_lib&swap	(71 atoi.c)\n");
	// long long int	num;
	ssize_t	num;
	int				isneg;
	int				i;

	num = 0;
	isneg = 1;
	i = 0;
	while (str[i] == ' ' || str[i] == '\t' || str[i] == '\n'
		|| str[i] == '\r' || str[i] == '\v' || str[i] == '\f')
		i++;
	if (str[i] == '+')
		i++;
	else if (str[i] == '-')
	{
		isneg *= -1;
		i++;
	}
	num = ft_atoi2(str, i, isneg);
	return (num);
}
