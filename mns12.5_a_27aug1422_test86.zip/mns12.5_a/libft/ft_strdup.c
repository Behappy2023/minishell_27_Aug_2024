/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strdup.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: kdanchal <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/08/25 18:51:38 by kdanchal          #+#    #+#             */
/*   Updated: 2023/09/12 17:31:46 by kdanchal         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

char	*ft_strdup(const char *s1)
{
	char	*s2;
	size_t	len;

	if (!s1)
		return(NULL);
	len = ft_strlen(s1) + 1;
	s2 = malloc(len * sizeof (char));
	if (!s2)
		return (NULL);
	ft_strlcpy(s2, s1, len);
	return (s2);
}

/*
#include <stdio.h>
#include <string.h>

int	main(void)
{
	printf("\n====test===== \n");
	char arr1[20] = "abcdef";

	printf("%s\n", ft_strdup(arr1));
	printf("%s\n",    strdup(arr1));
}
*/
