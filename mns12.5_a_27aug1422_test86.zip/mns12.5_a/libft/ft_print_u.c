/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_print_u.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: kdanchal <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/09/24 17:36:45 by kdanchal          #+#    #+#             */
/*   Updated: 2024/03/21 10:11:09 by kdanchal         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h" 

int	ft_len_u(unsigned int nb)
{
	size_t	len;

	len = 0;
	while (nb > 0)
	{
		nb = nb / 10;
		len++;
	}
	return (len);
}

int	ft_print_u(unsigned int args)
{
	unsigned int	nb;
	char			c;

	nb = args;
	if (args == 0)
	{
		if (write(1, "0", 1) == -1)
			return (-1);
		return (1);
	}
	if (args >= 10)
	{
		if (ft_print_u(args / 10) == -1)
			return (-1);
		c = args % 10 + '0';
		if (write(1, &c, 1) == -1)
			return (-1);
	}
	else
	{
		c = args % 10 + '0';
		if (write(1, &c, 1) == -1)
			return (-1);
	}
	return (ft_len_u(nb));
}

/*
#include <stdio.h>
int	main ()
{
	printf ("len=%d", ft_print_u(1234));

	printf("\n\n\n");

	printf ("len=%d", printf("%u", 1234));
	
}
*/
