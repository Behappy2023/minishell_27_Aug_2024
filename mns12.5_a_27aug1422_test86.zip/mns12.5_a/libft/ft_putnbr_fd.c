/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_putnbr_fd.c                                     :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: kdanchal <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/09/05 19:52:30 by kdanchal          #+#    #+#             */
/*   Updated: 2024/03/21 12:30:52 by kdanchal         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"
#include <unistd.h>

void	ft_putnbr_fd(int n, int fd)
{
	int	nbr;

	if (n == -2147483648)
	{
		ft_putstr_fd("-2147483648", fd);
		return ;
	}
	if (n < 0)
	{
		ft_putchar_fd('-', fd);
		nbr = n * -1;
	}
	else
		nbr = n;
	if (nbr >= 10)
	{
		ft_putnbr_fd(nbr / 10, fd);
		ft_putchar_fd((char)(nbr % 10 + '0'), fd);
	}
	else
	{
		ft_putchar_fd((nbr + '0'), fd);
	}
}
/*
#include <fcntl.h>
#include <stdio.h>

int	main(void)
{
	printf("=====Test=====");
	int abc = open("new_file", O_WRONLY | O_CREAT | O_TRUNC, 0777);  
	ft_putnbr_fd(789, abc);
	close (abc);
}
*/
