/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_putstr_fd.c                                     :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: kdanchal <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/09/05 19:34:31 by kdanchal          #+#    #+#             */
/*   Updated: 2023/09/13 11:29:15 by kdanchal         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

void	ft_putstr_fd(char *s, int fd)
{
	int	i;

	i = 0;
	while (s[i])
	{
		ft_putchar_fd(s[i], fd);
		i++;
	}
}
/*
#include <fcntl.h>
#include <stdio.h>

int	main (void)
{
	printf("\n\n=======test=========\n\n");
	ft_putstr_fd("Hello World!", 1);

	int abc = open("new_file", O_WRONLY | O_CREAT | O_TRUNC, 0777);
	ft_putstr_fd("789", abc);
}
*/
