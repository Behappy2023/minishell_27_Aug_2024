/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_tolower.c                                      :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: kdanchal <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/08/25 17:29:38 by kdanchal          #+#    #+#             */
/*   Updated: 2023/09/12 17:13:35 by kdanchal         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

int	ft_tolower(int c)
{
	if ('A' <= c && c <= 'Z')
		c += 32;
	return (c);
}

/*
#include <stdio.h>
#include <ctype.h>

int main(void)
{
	printf("\n\n=========== TESTING========\n\n");
	char	c;
	c = 'A';
	printf("%c, %c, %c\n", c, tolower(c), ft_tolower(c));
}
*/
