/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_print_p.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: kdanchal <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/09/24 22:30:31 by kdanchal          #+#    #+#             */
/*   Updated: 2024/03/21 12:33:37 by kdanchal         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

int	ft_len_p(unsigned long long args)
{
	size_t	len;

	len = 2;
	if (args == 0)
		return (3);
	while (args > 0)
	{
		args = args / 16;
		len++;
	}
	return (len);
}

//int	ft_print_p2(unsigned int  args)
int	ft_print_p2(unsigned long args)
{
	char	*base;
	int		tmp;

	base = "0123456789abcdef";
	if (args >= 16)
	{
		tmp = ft_print_p2(args / 16);
		if (tmp == -1)
			return (-1);
		if (write (1, &base [args % 16], 1) == -1)
			return (-1);
	}
	else
	{
		if (write(1, &base [args % 16], 1) == -1)
			return (-1);
	}
	return (1);
}

//int	ft_print_p(unsigned int args)
int	ft_print_p(unsigned long args)
{
	int	tmp;

	if (write(1, "0x", 2) == -1)
		return (-1);
	tmp = ft_print_p2(args);
	if (tmp == -1)
		return (-1);
	return (ft_len_p(args));
}
