/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_calloc.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: kdanchal <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/08/25 18:48:02 by kdanchal          #+#    #+#             */
/*   Updated: 2023/09/13 15:02:20 by kdanchal         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

void	*ft_calloc(size_t count, size_t size)
{
	void	*r;

	r = malloc(count * size);
	if (!r)
		return (NULL);
	ft_bzero(r, size * count);
	return (r);
}

/*
#include <stdio.h>
#include <stdlib.h>

int main() 
{
	printf ("\n ====== test====\n");
	size_t num = 5;
   	size_t size = sizeof(int);
   							
  	int *arr = (int *)calloc(num, size);
   	if (arr != NULL) 
   	{
       		printf("Mem ok\n");
        						
       		for (size_t i = 0; i < num; i++) 
		{
       			arr[i] = i;
  		}

		for (size_t i = 0; i < num; i++) 
		{		
			printf("arr= %d \n", arr[i]);
  		}
  		free(arr);
  		printf("Mem free\n");
    	} 
	else 
	{
      		printf("Mem fail\n");
    	}
}
*/
