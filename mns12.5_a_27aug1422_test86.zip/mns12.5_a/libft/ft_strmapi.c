/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strmapi.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: kdanchal <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/09/06 10:37:12 by kdanchal          #+#    #+#             */
/*   Updated: 2023/09/12 19:02:26 by kdanchal         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

char	*ft_strmapi(char const *s, char (*f)(unsigned int, char))
{
	unsigned int	i;
	char			*str;

	if (!s || !(s) || !f)
		return (NULL);
	i = 0;
	str = (char *)malloc(sizeof(char) * (ft_strlen(s) + 1));
	if (str == NULL)
		return (NULL);
	while (s[i] != '\0')
	{
		str[i] = f(i, s[i]);
		i++;
	}
	str[i] = '\0';
	return (str);
}
/*
#include <stdio.h>

char	test_strmapi_toupper(unsigned int i, char c)
{
	i--;
	return (ft_toupper(c));
}

char	test_strmapi_tolower(unsigned int i, char c)
{
	i--;
	return (ft_tolower(c));
}

char	test_next_char(unsigned int i, char c)
{
	return (c + i);
}

int	main (void)
{
	printf("\n%s\n", ft_strmapi("abcdef", test_next_char));
	printf("\"hello!\" : \"%s\"\n", ft_strmapi("HELLO!", test_strmapi_tolower));
	printf("\"BOOYA!\" : \"%s\"\n", ft_strmapi("booya!", test_strmapi_toupper));
}
*/
