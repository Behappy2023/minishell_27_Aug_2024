/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_atoi.c                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: kdanchal <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/08/25 18:37:18 by kdanchal          #+#    #+#             */
/*   Updated: 2024/03/21 12:30:12 by kdanchal         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

int	check_overflow(int isneg)
{
	if (isneg == 1)
		return (-1);
	else
		return (0);
}

int	ft_atoi2(const char *str, int i, int isneg)
{
	long	num;

	num = 0;
	while (ft_isdigit(str[i]))
	{
		num = (num * 10) + (str[i] - '0');
		i++;
		if (num < 0)
			return (check_overflow(isneg));
	}
	return (num * isneg);
}

int	ft_atoi(const char *str)
{
	int		isneg;
	int		i;

	isneg = 1;
	i = 0;
	while (str[i] == ' ' || str[i] == '\t' || str[i] == '\n'
		|| str[i] == '\r' || str[i] == '\v' || str[i] == '\f')
		i++;
	if (str[i] == '+')
		i++;
	else if (str[i] == '-')
	{
		isneg *= -1;
		i++;
	}
	return (ft_atoi2(str, i, isneg));
}
/*
#include <stdio.h>
#include <stdlib.h>
int	main(void)
{
	printf("\n======test======\n");
	char arr1[50] = "2147483648";
	printf("   atoi %s = %d\n", arr1,  atoi(arr1));
	printf("ft_atoi %s = %d\n", arr1, ft_atoi(arr1));
	
	char arr2[50] = "-18446744073709551616";
	printf("   atoi %s = %d\n", arr2,  atoi(arr2));
	printf("ft_atoi %s = %d\n", arr2, ft_atoi(arr2));

	char arr3[50] = " 9223372036854775809";
	printf("   atoi %s = %d\n", arr3,  atoi(arr3));
	printf("ft_atoi %s = %d\n", arr3, ft_atoi(arr3));

	char arr4[50] = "-2147483649";
	printf("   atoi %s = %d\n", arr4,  atoi(arr4));
	printf("ft_atoi %s = %d\n", arr4, ft_atoi(arr4));
}
*/
