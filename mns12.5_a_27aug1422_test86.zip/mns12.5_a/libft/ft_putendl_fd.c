/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_putendl_fd.c                                    :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: kdanchal <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/09/05 19:43:24 by kdanchal          #+#    #+#             */
/*   Updated: 2023/09/13 11:31:32 by kdanchal         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

void	ft_putendl_fd(char *s, int fd)
{
	ft_putstr_fd(s, fd);
	ft_putchar_fd('\n', fd);
}

/*
#include <fcntl.h>
#include <stdio.h>

int	main (void)
{
	printf("\n\n======test==========\n\n");
	ft_putendl_fd("Hello World!", 1);
	
	int abc = open("new_file", O_WRONLY | O_CREAT | O_TRUNC, 0777);
	ft_putendl_fd("Helloo", abc);
}
*/
