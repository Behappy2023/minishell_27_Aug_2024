/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strlcat.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: kdanchal <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/08/25 16:20:52 by kdanchal          #+#    #+#             */
/*   Updated: 2023/09/13 13:27:26 by kdanchal         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

size_t	ft_strlcat(char *dst, const char *src, size_t dstsize)
{
	size_t	i;
	size_t	j;
	size_t	d_size;
	size_t	s_size;

	d_size = ft_strlen(dst);
	s_size = ft_strlen(src);
	if (dstsize <= d_size)
		return (dstsize + s_size);
	i = d_size;
	j = 0;
	while ((i + j) < (dstsize - 1) && src[j] != '\0')
	{
		dst[i + j] = src[j];
		j++;
	}
	dst[i + j] = '\0';
	return (d_size + s_size);
}
/*
#include <stdio.h>
#include <string.h>

int	main(void)
{
	printf ("\n ======test=======\n");
	char 	arr1[20] = "abcdef";
	char 	arr2[20] = "1234";
	int	a;
	a = ft_strlcat(arr1, arr2, 11);
	printf("%d \n %s \n %s \n\n", a, arr1, arr2);
	
	char  	arr3[20] = "abcdef";
    	char  	arr4[20] = "1234";
    	int    	b;
    	b = strlcat(arr3, arr4, 11);
    	printf("%d \n %s \n %s \n\n", b, arr3, arr4);
}
*/
