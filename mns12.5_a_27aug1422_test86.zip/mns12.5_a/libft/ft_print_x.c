/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_print_x.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: kdanchal <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/09/23 19:41:30 by kdanchal          #+#    #+#             */
/*   Updated: 2024/03/21 10:11:24 by kdanchal         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

int	ft_len_x(unsigned int nb)
{
	size_t	len;

	len = 0;
	while (nb > 0)
	{
		nb = nb / 16;
		len++;
	}
	return (len);
}

int	ft_print_x2(char str, unsigned int args)
{
	int		tmp;
	char	*base;

	if (str == 'x')
		base = "0123456789abcdef";
	else if (str == 'X')
		base = "0123456789ABCDEF";
	if (args >= 16)
	{
		tmp = ft_print_x2(str, args / 16);
		if (tmp == -1)
			return (-1);
		if (write(1, &base[args % 16], 1) == -1)
			return (-1);
	}
	else if (args > 0)
	{
		if (write(1, &base[args % 16], 1) == -1)
			return (-1);
	}
	return (1);
}

int	ft_print_x(char str, unsigned int args)
{
	unsigned int	len;
	unsigned int	nb;
	int				tmp;

	nb = args;
	if (args == 0)
	{
		if (write (1, "0", 1) == -1)
			return (-1);
		return (1);
	}
	tmp = ft_print_x2(str, args);
	if (tmp == -1)
		return (-1);
	len = ft_len_x(nb);
	return (len);
}
