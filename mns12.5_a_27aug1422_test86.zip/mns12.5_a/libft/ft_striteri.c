/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_striteri.c                                      :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: kdanchal <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/09/05 16:43:05 by kdanchal          #+#    #+#             */
/*   Updated: 2023/09/12 19:04:03 by kdanchal         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"
#include <stddef.h>

void	ft_striteri(char *s, void (*f)(unsigned int, char*))
{
	size_t	i;

	if (!s || !(*s) ||!f)
		return ;
	i = 0 ;
	while (s[i])
	{
		(*f)(i, &s[i]);
		i++;
	}
}

/*
#include <stdio.h>

void	test_next2(unsigned int i,char *c)
{
	printf("%s %d\n", c ,i);
}

void ft_putstr(const char *str)
{
    while (*str != '\0') 
    {
        write(1, str, 1); 
        str++;
    }
}

void	test_striteri_print(unsigned int i, char *c)
{
	i--;
	write(1, c, 1);
}

int	main (void)
{
	printf("\n ==== test === \n");
	ft_striteri("abcd", test_next2);

	ft_putstr("\"Hello!\" : \"");
	ft_striteri("Hello!", test_striteri_print);
	ft_putstr("\"\n");
	ft_putstr("\"BOOYA!\" : \"");
	ft_striteri("BOOYA!", test_striteri_print);
	ft_putstr("\"\n");
}
*/
