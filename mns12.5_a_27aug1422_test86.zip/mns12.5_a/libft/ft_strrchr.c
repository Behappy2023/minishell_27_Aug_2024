/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strrchr.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: kdanchal <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/08/25 17:54:19 by kdanchal          #+#    #+#             */
/*   Updated: 2023/09/13 14:10:40 by kdanchal         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

char	*ft_strrchr(const char *str, int c)
{
	char			*p;
	unsigned char	ch;
	size_t			offset;

	ch = c;
	offset = ft_strlen(str);
	p = (char *)str + offset;
	if (ch == '\0')
		return (p++);
	while (p >= str)
	{
		if (*p == ch)
			return (p);
		p--;
	}
	p = NULL;
	return (p);
}

/*
#include <stdio.h>
#include <string.h>

int main(void)
{
    	printf("\n====test=====\n");
    	char arr1[20] = "abcdabcd";
    	printf("%s\n", ft_strrchr(arr1, 'd'));
    	printf("%s\n",     strrchr(arr1,'d'));
}
*/
