/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   get_next_line_utils.c                              :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: kdanchal <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/11/02 15:07:06 by kdanchal          #+#    #+#             */
/*   Updated: 2024/03/21 12:24:01 by kdanchal         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

size_t	ft_strlen_g(const char *s)
{
	size_t	i;

	if (!s)
		return (0);
	i = 0;
	while (s[i])
	{
		i++;
	}
	return (i);
}

char	*ft_strchr_g(const char *s, int c)
{
	if (!s)
		return (NULL);
	while (s && *s != (char)c)
	{
		if (!(*s))
			return (NULL);
		s++;
	}
	return ((char *)s);
}

char	*ft_strndup_g(const char *s1, size_t n)
{
	char	*s2;
	size_t	i;

	if (n < 1 || s1 == NULL)
		return (NULL);
	i = 0;
	s2 = malloc(sizeof(char) * (n + 1));
	if (s2 == NULL)
		return (NULL);
	while (s1[i] && i < n)
	{
		s2[i] = s1[i];
		i++;
	}
	s2[i] = '\0';
	return (s2);
}

char	*ft_strjoin_g(char const *s1, char const *s2)
{
	char	*str;
	size_t	i;
	size_t	j;

	str = malloc(sizeof(char) * (ft_strlen_g(s1) + ft_strlen_g(s2) + 1));
	if (!str || !s1 || !s2)
		return (NULL);
	i = 0;
	j = 0;
	while (s1[i] != '\0')
		str[i++] = s1[j++];
	j = 0;
	while (s2[j] != '\0')
		str[i++] = s2[j++];
	str[i] = '\0';
	return (str);
}

void	gnl6_keep(t_dat *data)
{
	char	*keep;

	data->nl = NULL;
	keep = ft_strchr_g(data->s, '\n') + 1;
	keep = ft_strndup_g(keep, ft_strlen_g(keep));
	free(data->s);
	data->s = keep;
	data->nl = ft_strchr_g(data->s, '\n');
}
/*
#include <stdio.h>
#include <string.h>

int	main ()
{
	printf("\nlen=%d", ft_strlen(NULL));
	
	char	*s;
//	s = "abcdabcd";
	s = NULL;
//	printf("\nstrchr =%s",ft_strchr(s, NULL)  	);

	
	char	*s2;
	s2 = ft_strndup(s , 1);
	printf("\nfake_dupn =%s", s2);

	char	*s3;	
	s3 =	strndup(s , 1);
	printf("\nreal_dupn =%s", s3);

}

*/
