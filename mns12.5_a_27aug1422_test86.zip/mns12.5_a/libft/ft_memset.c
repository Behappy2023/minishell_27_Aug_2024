/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   memset.c                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: kdanchal <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/08/25 14:36:52 by kdanchal          #+#    #+#             */
/*   Updated: 2023/09/13 12:15:54 by kdanchal         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

void	*ft_memset(void *b, int c, size_t len)
{
	unsigned char	*p;
	unsigned char	ch;

	p = (unsigned char *)b;
	ch = c;
	while (len--)
	{
		*p = ch;
		p++;
	}
	return (b);
}

/*
#include <stdio.h>
#include <string.h>

int	main(void)
{
	printf("\n ====test====\n");
	char arr1[20] = "abcd";
	char arr2[20] = "abcd";
	printf("%s \n", ft_memset(arr1, 'y', 2));
	printf("%s \n", memset(arr2, 'y',2) );
}
*/
