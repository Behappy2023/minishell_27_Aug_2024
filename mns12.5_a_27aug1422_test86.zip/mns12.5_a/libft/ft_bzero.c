/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_bzero.c                                         :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: kdanchal <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/08/25 14:32:46 by kdanchal          #+#    #+#             */
/*   Updated: 2023/09/13 13:13:25 by kdanchal         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"
#include <stddef.h>

void	ft_bzero(void *s, size_t n)
{
	unsigned char	*p;

	p = (unsigned char *)s;
	while (n != 0)
	{
		*p = '\0';
		p++;
		n--;
	}
}

/*
#include <stdio.h>
#include <string.h>

int	main (void)

{
	printf("\n\n=========== TEST ============\n\n");

	char	arr1[20] = "abc";
	char	arr2[20] = "abc";
	bzero(arr1, 2);
	ft_bzero(arr2, 2);

	int	i;
	i = 0;
	while (i < 3 && arr1[i] ==arr2[i])
		i++;

	printf("[%c] [%c] [%c] \n",arr1[0] ,arr1[1], arr1[2]);
	printf("[%c] [%c] [%c] \n", arr2[0], arr2[1], arr2[2]);
}
*/
