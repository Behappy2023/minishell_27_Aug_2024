/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_toupper.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: kdanchal <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/08/25 17:28:03 by kdanchal          #+#    #+#             */
/*   Updated: 2023/09/12 17:12:16 by kdanchal         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

int	ft_toupper(int c)
{
	if ('a' <= c && c <= 'z')
		c -= 32;
	return (c);
}

/*
#include <stdio.h>
#include <ctype.h>    

int main (void)
{
	printf("\n\n======== TESTING=========\n\n");
	char	c;

	c = 'a';
	printf(" %c, %c, %c \n", c, toupper(c), ft_toupper(c));
}
*/
