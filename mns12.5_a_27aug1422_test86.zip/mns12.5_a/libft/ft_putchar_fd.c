/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_putchar_fd.c                                    :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: kdanchal <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/09/04 19:26:24 by kdanchal          #+#    #+#             */
/*   Updated: 2023/09/13 11:25:30 by kdanchal         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>

void	ft_putchar_fd(char c, int fd)
{
	write(fd, &c, 1);
}

/*
#include <stdio.h>
#include <fcntl.h>

int	main (void)
{
	printf("\n ====test === \n");
	ft_putchar_fd('y', 1);

    	int abc = open("new_file", O_WRONLY | O_CREAT | O_TRUNC, 0777);
	ft_putchar_fd('c', abc);
}
*/
