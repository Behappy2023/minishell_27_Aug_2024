/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_memcmp.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: kdanchal <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/08/25 18:21:45 by kdanchal          #+#    #+#             */
/*   Updated: 2023/09/12 17:23:22 by kdanchal         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

int	ft_memcmp(const void *s1, const void *s2, size_t n)
{
	const char	*str1;
	const char	*str2;
	size_t		i;

	if (n == 0)
		return (0);
	str1 = (const char *)s1;
	str2 = (const char *)s2;
	i = 0;
	while ((i < n - 1) && str1[i] == str2[i])
		i++;
	return ((unsigned char)str1[i] - (unsigned char)str2[i]);
}

/*
#include <string.h>
#include <stdio.h>

int	main (void)
{
	printf("\n====test===== \n");
	char arr1[20] = "abcdef";
	char arr2[20] = "abcdee";

	printf("%d\n", ft_memcmp(arr1, arr2, 6));
	printf("%d\n",    memcmp(arr1, arr2, 6));

	printf("%d\n", ft_memcmp(arr1, arr2, 0));
    	printf("%d\n",    memcmp(arr1, arr2, 0));
}
*/
