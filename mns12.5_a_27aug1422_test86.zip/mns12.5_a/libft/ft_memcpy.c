/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_memcpy.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: kdanchal <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/08/25 15:11:57 by kdanchal          #+#    #+#             */
/*   Updated: 2023/09/13 13:19:30 by kdanchal         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

// void	*ft_memcpy(void *dst, const void *src, size_t n)
// {
// 	char		*dp;
// 	const char	*sp;

// 	if (!dst && !src)
// 		return (NULL);
// 	if (n == 0 || (dst == src))
// 		return (dst);
// 	dp = (char *)dst;
// 	sp = (const char *)src;
// 	while (n != 0)
// 	{
// 		if (*dp != *sp)
// 			*dp = *sp;
// 		dp++;
// 		sp++;
// 		n--;
// 	}
// 	return (dst);
// }

/*
#include <stdio.h>
#include <string.h>

int	main (void)
{
	printf("\n ====test===== \n");
	char data2[20] = "12345678";
	char 	src[20] = "abcd";
	char 	dst[20] = "1234";
	memcpy(dst, src, 2);
	printf("src: %s \n", src);
	printf("dst: %s \n", dst);
}
*/



// #include <stddef.h> // สำหรับการใช้ size_t

// void *ft_memcpy(void *dst, const void *src, size_t n) 
// {
//     // แปลงพอยน์เตอร์ให้เป็นพอยน์เตอร์ชนิด char
//     char *dest = (char *)dst;
//     const char *source = (const char *)src;

//     // ตรวจสอบว่า dst และ src ไม่ใช่ NULL
//     if (dest == NULL || source == NULL) {
//         return NULL;
//     }

//     // ใช้ while loop ในการคัดลอกข้อมูลทีละไบต์
//     while (n--) {
//         *dest++ = *source++;
//     }

//     // คืนค่าพอยน์เตอร์ dst กลับไป
//     return dst;
// }


void	*ft_memcpy(void *dst, const void *src, size_t n)
{
	size_t	i;

	i = 0;
	if (!dst && !src)
		return (0);
	while (i < n)
	{
		((char *)dst)[i] = ((char *)src)[i];
		i++;
	}
	return (dst);
}
