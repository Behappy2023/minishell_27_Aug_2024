/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_printf.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: kdanchal <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/09/17 16:00:22 by kdanchal          #+#    #+#             */
/*   Updated: 2024/03/21 10:45:12 by kdanchal         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

int	ft_mode(const char *str, va_list *args)
{
	size_t	len;

	len = 0;
	if (*str == 'c')
		len += ft_print_c(va_arg(*args, int));
	else if (*str == 's')
		len += ft_print_s(va_arg(*args, char *));
	else if (*str == 'd' || *str == 'i')
		len += ft_print_d(va_arg(*args, int));
	else if (*str == 'p')
		len += ft_print_p(va_arg(*args, unsigned long long));
	else if (*str == 'u')
		len += ft_print_u(va_arg(*args, unsigned int));
	else if (*str == 'x' || *str == 'X')
		len += ft_print_x(*str, va_arg(*args, unsigned int));
	else if (*str == '%')
		len += ft_print_c('%');
	return (len);
}

int	ft_printf(const char *str, ...)
{
	va_list			args;
	unsigned int	len;
	int				tmp;

	len = 0;
	if (!str)
		return (0);
	va_start(args, str);
	while (*str)
	{
		if (*str == '%')
		{
			str++;
			tmp = ft_mode(str, &args);
		}
		else
			tmp = ft_print_c(*str);
		if (tmp == -1)
			return (-1);
		len += tmp;
		str++;
	}
	va_end(args);
	return (len);
}
/*
#include <stdio.h>
int	main(void)
{
	int	i;

	i = printf("%p", "");
	printf("\n%d\n", i);


	i = ft_printf("%p", "");
	printf("\n%d\n", i);
}
*/
