#include "minishell.h"

/*

Test  75: ✅⚠️  cat <"./test_files/infile_big" | echo hi 
>8 cat <7
 ls | cat  | ec -l

 <f1 <f2 cat <f5| <f1 <f2 cat

//const char *check is "|&;<>"
//a b"c" "d" 'e' 'f'g $ $h < i >> j >k >>l | 123456
// cat < f1 | ls | >f2 gh >> asdf <<efg "sdg"sdgv sdv'sdv' sdvb"sdv"     " " 

export aa="123 456" "cc=999"


*/

// int	g = 30;  //91  108+105
int	g = 7; 
// int	9 = 11;

	//	   7= 	no option
	// 2 	= 	print
	// 	3	= 			exit
	//   5	= 					SHLVL
	// 23 	=6 
	// 2 5	=10 
	// 	35	=15
	// 235	=30	print exit	SHLVL
	//   7
	//  11
//	export aa="		55	88"
// export				dd="99"

void	ft_print_list(t_data *d, char *s)
{
	int	mode = 3;
	//	   7= no option
	// 2 	= print reverse
	// 	3	= 					 print symbol + status
	//   5	= 
	// 23 	=6 print reverse	+print symbol + status
	// 2 5	=10 
	// 	35	=15
	// 235	=30
	printf("	%s\n", s);
	d->current = d->head;
	int	i = 0;
	while (d->current)
	{
		printf("	Node %d: %s", i++, d->current->content);
		if (mode % 3 == 0) //<=======
		{
			if (d->current->symbol)
				printf("		symbol=%d		%d\n", d->current->symbol, d->current->status);
			else
				printf("		%d		status=%d\n", d->current->symbol, d->current->status);
		}
		else
			printf("\n");
		if (!d->current->next)
			d->tail = d->current;
		d->current = d->current->next;
	}
	if (mode % 2 == 0)//<=======
	{
		if(d->tail)
	        d->current = d->tail;
        i--;
        printf("\n    reverse\n");
        while (d->current)
        {
            printf("	Node %d: %s", i--, d->current->content);
            if (d->current->symbol)
                printf("		symbol=%d		%d\n", d->current->symbol, d->current->status);
            else
                printf("		%d		status=%d\n", d->current->symbol, d->current->status);
            d->current = d->current->prev;
        }
		d->tail = NULL;
	}
	printf("\n");
}



void	ft_set_start_2_connect2(t_data *d)
{
	d->cmd = NULL;
	d->fd_in = 0;
	d->name_file_in = NULL;
	d->file_in_first_status = 1;
	d->file_in_first_name = NULL;
	d->file_out_before_file_in =1;

	d->fd_out = 1;
	d->name_file_out = NULL;
	d->file_out_first_status =1;
	d->file_out_first_name = NULL;

	d->have_pipe = 0;
	d->history_pipe = 0;
		d->fd_pipe[0] = 0;
		d->fd_pipe[1] = 1;
		d->pid = 0;
	// d->save_stdin = dup(0);
	// d->save_stdout = dup(1);

	// d->word_stop = ft_strdup("");
	// d->word_add = ft_strdup("");
	d->word_stop = NULL;
	d->word_add = NULL;
	d->word_real = ft_strdup("");	//free
	d->word_tmp = ft_strdup("");	//free


	d->error_open_file_in_normal = 0;
	d->error_file_in_normal_name = NULL;
	d->error_open_file_out_trunc = 0;
	d->error_file_out_trunc_name = NULL;
	d->error_open_file_out_append = 0;
	d->error_file_out_append_name = NULL;

	d->error_open_some_file = 0;
}


void	ft_set_start_1(t_data *d, int	ac, char **av, char **env)
{

    d->ac = ac;
    d->av = av;
    d->env = env;
	d->env_list = ft_env_get_to_list(env, d); //free

		// d->export_list = NULL;
	d->table = NULL;
	d->user = NULL;
	d->exit_stat = 0;

	getcwd(d->pwd,99999);
	getcwd(d->old_pwd,99999);
	d->shell_level = 1;
		d->input = NULL;
		d->sp_input = NULL;

	d->error_syntax = 0;
		d->head = NULL;
		d->tail = NULL;
		d->current = NULL;
}


void	ft_set_start(t_data *d, int	ac, char **av, char **env)
{
	ft_memset(d, 0, sizeof(t_data));
	ft_set_start_1(d, ac, av, env);
	ft_set_start_2_connect2(d);


	(void)d;
	(void)ac;
	(void)av;
	(void)env;

}





void	ft_minishell_loop(t_data *d)
{
	(void)d;
    while (1)
    {
		ft_handle_signals();
		if(g%2==0)printf("	history_pipe = %d	(300 main.c)\n", d->history_pipe);

		ft_parser_system(d);

		ft_exec_system(d);
		if(g%2==0)printf("	==================finish=======\n");
		if(g%3==0){printf("	d->exit_status = ");printf("\033[0;32m%d\033[0m", d->exit_stat);printf(" 	(343 main.c)\n\n\n");}
		if (d->input)
		{
			ft_free_system(d);
					// ft_free_list(d->head);
					// ft_free_split_input(d->sp_input);
					// free(d->input);
		}
		if(g%2==0)printf("	history_pipe = %d	(313 main.c)\n", d->history_pipe);

   }
	
	ft_free_system_2(d);
		/*	
			rl_clear_history();
			free(d->word_real);				// ft_free_set_start
			free(d->word_tmp );				// ft_free_set_start
			free(d->user); 
			free(d->table);
			// ft_env_free_array(d->env);		// <======
			ft_env_free_list(d->env_list);	// ft_free_set_start
			free(d);
		*/
}


int main(int ac, char **av, char **env)
{
    t_data  *d;
	(void)d;
	(void)ac;
	(void)av;
	(void)env;
    d = malloc(sizeof(t_data));
    if (!d)
    {
		printf("Error maloc: Cannot allocate memory");
        return (1);
    }
	
	ft_set_start(d, ac, av, env);
	if(g%2==0)
	{
		printf("	pls fill issue\n");
		printf("	-1.unset PWD   cd $PWD\n");
		printf("	-2. ./mini ./mini ./mini  exit seg fau\n");

		printf("	-3. echo $bb\n");
		printf("\n");
	}
	ft_minishell_loop(d);
    return (0);
}


// ==206389== LEAK SUMMARY:
// ==206389==    definitely lost: 		0 bytes in 	 0 blocks
// ==206389==    indirectly lost: 		0 bytes in 	 0 blocks
// ==206389==      possibly lost: 		0 bytes in 	 0 blocks
// ==206389==    still reachable: 208,193 bytes in 222 blocks
// ==206389==         suppressed: 		0 bytes in 	 0 blocks


// int main(void)	// 208,193 
// {
// 	char	*input;
// 	// input = readline("\033[0;33m\033[1m$ \033[0m");
// 	while (1)
// 	{
// 		input = readline("\033[0;33m\033[1m$$$$$$$$$ \033[0m");
	
// 		if (input[0] == 'a')
// 			break;
// 		free(input);
	
// 	}
// 	add_history(input);
// 	rl_clear_history();
// 	free(input);
// 	return(0);
// }
