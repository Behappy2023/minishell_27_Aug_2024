/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   minishell.h                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: kdanchal <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/08/27 18:05:40 by kdanchal          #+#    #+#             */
/*   Updated: 2024/04/26 11:47:49 by kdanchal         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef MINISHELL_H
# define MINISHELL_H

# include "./libft/libft.h"
# include <ctype.h>
# include <fcntl.h>
# include <readline/history.h>
# include <readline/readline.h>
# include <signal.h>
# include <stdio.h>
# include <stdlib.h>
# include <string.h>
# include <sys/wait.h>
# include <unistd.h>



# define RED		"\033[0;31m"	// use red
# define GREEN		"\033[0;32m"	// use green
# define YELLOW		"\033[0;33m"	// use yell
# define BLUE		"\033[0;34m"
# define MAGENTA	"\033[0;35m"	// use pink
# define CYAN		"\033[0;36m"	// use blue
# define GRAY		"\033[0;37m"
# define LRED		"\033[0;91m"
# define BOLD		"\033[1m"
# define RESET		"\033[0m"



extern int g;

typedef struct s_split
{
	char 	**tokens;
    char    buf[1024];
    char    quote; //("-", '-')
    int     ib; //index_buf
    int     it; //index_token
    int     iq; //index_quote("", '')
}	t_split;


// ft_super_split_2
t_split 	ft_skip_space(t_split *sp);
int			ft_isspace(char *str);
t_split 	ft_ischeck(char *str, t_split *sp);
int 		ft_found_quote(char *str,t_split *sp);
t_split		ft_is_type_of_tokens(char *str, const char *check, t_split *sp);

// ft_super_split_1
t_split		ft_isset(t_split *sp);
void		*ft_realloc(void *ptr, size_t old_size, size_t new_size);
t_split 	ft_isheredoc_appen(char *str, t_split *sp);
int 		ft_inquote(char *str, t_split *sp);
char 		**ft_super_split(char *str, const char *check);





typedef struct s_env
{
	char			*name;
	char			*value;
	int				status;
	int				env_shlvl;
	int				high_level;
	//  0=env			print 	+add 							+ send env
	//  1=export		print	+add	+sort
	//  2=add serect	no print				+echo can call

	struct s_env	*next;
}					t_env;

typedef struct s_list
{
	char			*content;
	int				symbol;
	//	0	non status
	//	1	""
	//	2	''
	//	3	$
	//	4	<
	//	5	<<
	//	6	>
	//	7	>>
	//	8	|

	// if left < << >> > $   	will have type
	// if left | 				will have type  start join  cmd rigth
	// if right |				stop join	get cmd left

	int				status;
	//	0	non status
	//	1	" double
	//	2	' single
	//	3	$ dollar  interrup ""
	//	4	infile
	//	5	here doc
	//	6	outfile
	//	7	outfile2
	//	8	cmd

	struct s_list	*next;
	struct s_list	*prev;

}					t_list;

typedef struct s_data
{
	//===>ft_set_start
	int				ac;
	char			**av;
	char			**env;
	t_env			*env_list;
	// t_env			*save_env_list;
	t_env			*export_list;
	char			*table;
	char			*user;
	
	// t_env		*export_serect_list;
	int				exit_stat;
	// long long int	exit_stat;
	char			pwd[99999];
	char			old_pwd[99999];
	// char			*pwd;
	// char			*old_pwd;
	// pid_t			pid_minishell;
	// int				round_minishell;
	int				shell_level;
	
	//===>ft_parser_system
	char			*input;
	char			**sp_input;

	//===>ft_set_status
	int				error_syntax;

	//===> ft_list_add_back
	t_list			*head;
	t_list			*tail;
	t_list			*current;


	//===> ft_connect2
	int			 	error_cmd_null_status;
	char			*cmd;
	int				fd_in;
	char			*name_file_in;
	int				file_in_first_status;
	char			*file_in_first_name;
	int				file_out_before_file_in;


	int				fd_out;
	char			*name_file_out;
	int				file_out_first_status; //<==
	char			*file_out_first_name; //<==

	// char			*name_file_out;
	int				have_pipe;
	int				history_pipe;
	int				have_symbol_indirect;
	int				fd_pipe[2];
	pid_t			pid;
	char			*word_stop;
	char			*word_add;
	char			*word_real;
	char			*word_tmp;



	// int				save_stdin;
	// int				save_stdout;


	//==>ft_open_file
	int				error_open_file_in_normal;
	char			*error_file_in_normal_name;

	int				error_open_file_out_trunc;
	char			*error_file_out_trunc_name;

	int				error_open_file_out_append;
	char			*error_file_out_append_name;
	
	int				error_open_some_file;
	int				error_first_open_will_show;	//  1nor no_file 	2nor per
												//	3truc no_file 	4trunc no per
												//  5 appen no file	6appen no per


}					t_data;

// main
void				ft_print_list(t_data *d, char *s);
void				ft_set_start_2_connect2(t_data *d);
void				ft_set_start_1(t_data *d, int ac, char **av, char **env);
void				ft_set_start(t_data *d, int ac, char **av, char **env);
void				ft_minishell_loop(t_data *d);
// int					main(int ac, char **av, char **env);

// ft_free.c
void 				ft_close_fd_2(t_data *d);
void 				ft_close_fd(t_data *d);
void				ft_free_system_2(t_data *d);
void				ft_free_system(t_data *d);
void				ft_free_split(char **sp_xxx);
void				ft_free_2split(char **sp_path, char **sp_cmd, t_data *d);
void				ft_free_3split(char **sp_xx1, char **sp_xx2, char **sp_xx3, t_data *d);

// ft_signal.c
void				ft_handle_signals(void);
void				ft_handle_signals_for_here_doc(void);

///////////////////////////////////////////////////

// ft_builtin
int 				ft_is_builtin_for_set_status(char *cmd, t_data *d); //use
int 				ft_is_minishell(char *cmd, t_data *d);
void				ft_exec_builtin_cd_exit(char *cmd, t_data *d);
void				ft_exec_builtin(char *cmd, t_data *d, char *export_no_print);
int 				ft_is_chk(char *cmd, t_data *d);
void				ft_free_split(char **sp_xxx);
int					ft_is_builtin(char *cmd, t_data *d);
int					ft_is_builtin_set_1(char *cmd, t_data *d);
int					ft_is_builtin_set_2(char *cmd);
int					ft_is_builtin_set_3(char *cmd);
// int					ft_is_builtin(char *cmd);
int 				ft_is_builtin_cd_exit(char *cmd);

// ft_cd
void				ft_cd(char *cmd, t_data *d);

// ft_echo
int					ft_is_echo(char *cmd, t_data *d);
char				*ft_echo_get_env_var_value(t_env *env_list, const char *var, t_data *d);
void				ft_echo(char *cmd, t_data *d);
char				*ft_echo_dollar(char *cmd, t_data *d);

// ft_env
void				ft_env(char *cmd, t_data *d);

// ft_exit
int					ft_is_exit(char *cmd, t_data *d);
void				ft_exit(char *cmd, t_data *d);
void				ft_exit_real(char *cmd, t_data *d);
void				ft_exit_fake(char *cmd, t_data *d);


// // ft_export
// int 				ft_is_export(char *cmd, t_data *d);
// char				*ft_strtok(char *str, const char *delim);
// void				ft_export_insert_sort(t_env **sorted, t_env *new_node);
// t_env				*ft_export_sort_list(t_env *head); // for export cmd
// char				*ft_export_strjoin_space(char const *s1, char const *s2);
// char				*ft_export_first_is_num(char *cmd, t_data *d);
// char 				*ft_trim_quotes(char *str);
// void				ft_export_have_parameter(char *cmd, t_env **env_list, t_data *d);
// void				ft_export(char *cmd, t_data *d);
// void				ft_export_no_print(char *cmd, t_data *d);

// void 				ft_export_have_args(char *cmd, t_env **env_list, t_data *d);
// int					ft_export_name_args_correct_2(char *cmd);
// char				*ft_export_name_args_correct(char *cmd, t_data *d);


//////////////export edit by gun ///////////////
// // ft_export_1
void 				ft_export_insert_sort(t_env **sorted, t_env *new_node);
t_env 				*ft_export_sort_list(t_env *head);
void				ft_export(char *cmd, t_data *d);
void 				ft_export_have_args(char *cmd, t_env **env_list, t_data *d);

int					ft_is_export(char *cmd, t_data *d);
void				ft_export_no_print(char *cmd, t_data *d);

// // ft_export_2
char 				*ft_export_strjoin_space(char const *s1, char const *s2);
void				ft_print_bash_export(char *sp_cmd, t_data *d);
int					ft_export_name_args_correct_2(char *cmd);
void 				ft_move_quote(char *str);
char				*ft_export_name_args_correct(char *cmd, t_data *d);


// // ft_export_3
void 				ft_if_current_empty2(t_env **env_list, char *token, t_env *current, t_data *d);
void    			ft_no_equal_sign(char *token,t_env **env_list,t_data *d);
void 				ft_current_empty1(t_env *current, char *name, char *value,t_data *d, t_env **env_list);
void 				ft_have_equal_sign(char *token, char *equal_sign, t_data *d, t_env **env_list);

// // ft_export_4 utils
char 				*ft_strtoken(char *str, const char *delim);
char				*ft_strcpy(char *dst, const char *src);
char				*ft_strncpy(char *dst, const char *src, size_t n);
void  				ft_if_malloc_failed(void);
char 				*ft_trim_quotes(char *str);


// ft_export_serect
void				ft_export_secret(char *cmd, t_env *env_list, t_data *d);

// ft_pwd
void				ft_pwd(char *cmd, t_data *d);


// typedef struct s_shell
// {
// 	t_env			*env_list;
// 	int				shell_level;
// 	struct s_shell	*next;
// 	struct s_shell *prev; // เพิ่ม prev เพื่อทำลิงค์แบบสองทิศทาง
// }					t_shell;


// // ft_shell_level
// t_shell				*ft_create_shell(t_shell *prev_shell, int shell_level);
// void				ft_delete_shell(t_shell **shell);

// ft_unset
void				ft_unset_remove_node(t_env **env_list, const char *name); // unset
void				ft_unset(char *cmd, t_data *d);
int					ft_is_unset(char *cmd, t_data *d);

///////////////////////////////////////////////////

// ft_child_parrent
void				ft_child_check_error_open_file(t_data *d);
void				ft_child_child(t_data *d);
void				ft_child(t_data *d);
void				ft_parrent(t_data *d, t_list *current);


// ft_connect2
void				ft_set_connect2(t_data *d);
t_list				*ft_check_file_in_out_cmd_pipe(t_data *d ,t_list *current);
int					ft_connect2(t_data *d, t_list *current);
// void 				ft_connect(t_data *d, t_list *list_cmd);

// ft_exec_system
void				ft_exec_system(t_data *d);

// ft_exec
void				ft_exit_from_exec(char *s1, char *s2, char *s3, int type_exit, t_data *d);
void				ft_free_2split(char **sp_path, char **sp_cmd, t_data *d);
char				*ft_find_path(char **env);
int					ft_is_cmd(char *cmd, char **env, t_data *d);
void				ft_exec(char *cmd, char **env, t_data *d);
int					ft_cmd_have_path(char *cmd);
void				ft_exec_have_path(char *cmd, char **env, t_data *d);
char 				**ft_convert_env_list_to_array(t_env *env_list);
void 				ft_env_free_array(char **env_array);


// ft_open_file
int					ft_open_file_out_append(char *name_file, t_data *d);
int					ft_open_file_out_trunc(char *name_file, t_data *d);
int					ft_open_file_in_here_doc(char *content_stop_word, t_data *d);
int					ft_open_file_in_normal(char *name_file, t_data *d);

///////////////////////////////////////////////////

// ft_get_env_to_list
t_env				*ft_env_list_new(char *name, char *value);
void				ft_env_list_add_back(t_env **head, char *name, char *value);
void				ft_env_free_list(t_env *head);
t_env				*ft_env_get_to_list(char **env, t_data *d);

// ft_list_add_back
t_list				*ft_list_new(char *token);
void				ft_list_add_back(t_list **head, char *token);
void				ft_free_list(t_list *head);

// ft_merge_status_8
void				ft_merge_status_8(t_list **head);
char				*ft_strjoin_space(char const *s1, char const *s2);
char				*ft_strjoin_no_space(char const *s1, char const *s2); //


// ft_parser_system
int 				ft_is_one_quotes(char *str);
char				*ft_chk_signal_chk_one_quotes(t_data *d);
void				ft_parser_system(t_data *d);

// ft_setsymbol_status
// char *ft_replace_quotes(const char *str, int mode);  // 1=space    2=non space
char 				*ft_replace_quotes(char *str, int mode);  // 1=space    2=non space
void				ft_set_symbol(t_list **head);
void				ft_set_status(t_list **head, t_data *d);
void				ft_set_symbol_status(t_list **head, t_data *d);

// ft_split_input
void				*ft_realloc(void *ptr, size_t old_size, size_t new_size);
void				ft_free_split_input(char **tokens);

char				**ft_split_input(char *str, const char *check);

///////////////////////////////////////////////////

#endif
