#include "minishell.h"
# include <signal.h>



void	ft_sigint_handler(int signo)
{
	(void)signo;
	write(1, "\n", 1);
	// write(1, "minishell$ ", 11);
	// printf("ミニシェル ミニヘル ミニヘルプ:");

    // rl_replace_line("", 0);
    // rl_done = 1; // Force readline to return
	printf("\033[0;34mミニシェル ミニヘル ミニヘルプ:\033[0m");
}




void	ft_handle_signals(void)
{
	signal(SIGINT, ft_sigint_handler);			//ctrl + c
	// signal(SIGQUIT, ft_sigquit_handler);
	signal(SIGQUIT, SIG_IGN);					//ctrl + '\'
	signal(SIGTERM, SIG_IGN);					//ctrl + d


}



void ft_sigint_handler_here_doc(int signo) {
    (void)signo;
    write(1, "\n", 1);
    // rl_replace_line("", 0);
    // rl_done = 1; // Force readline to return
    printf("\033[0;34mミニシェル ミニヘル ミニヘルプ:\033[0m");
}

void ft_sigterm_handler_here_doc(int signo) {
    (void)signo;

	    rl_replace_line("", 0);
    rl_done = 1; // Force readline to return
    printf("\033[0;34mミニシェル ミニヘル ミニヘルプ:\033[0m");


    printf("\033[0;34mミニシェル ミニヘル ミニヘルプ:\033[0m");
    rl_done = 1; // Force readline to return
}

void ft_handle_signals_for_here_doc(void) {
    signal(SIGINT, ft_sigint_handler_here_doc);  // Handle Control+C
    signal(SIGQUIT, SIG_IGN);                    // Ignore Control+'\'
    signal(SIGTERM, ft_sigterm_handler_here_doc);// Handle Control+D
}
