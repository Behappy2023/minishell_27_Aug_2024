


#include "../minishell.h"




void ft_env(char *cmd, t_data *d)
{
    (void)cmd;

    if(g%2==0)printf("	now=%s	(12 env.c)\n", d->pwd);
    if(g%2==0)printf("	old=%s	(13 env.c)\n", d->old_pwd);

    int tmp_shell_level = d->shell_level;

    while (tmp_shell_level)
    {
        t_env *current_env = d->env_list;

        while (current_env)
        {
            if (ft_strcmp(current_env->name, "PWD") == 0)
            {
                current_env->value = d->pwd;
            }
            if (ft_strcmp(current_env->name, "OLDPWD") == 0)
            {
                current_env->value = d->old_pwd;
            }
            if (ft_strcmp(current_env->name, "SHLVL") == 0)
            {
                char *new_shlvl = ft_itoa(d->shell_level);
                if (new_shlvl)
                {
                    free(current_env->value);
                    current_env->value = new_shlvl;
                }
            }
			if(g%2==0)
			{
				if (ft_strcmp(current_env->name, "SHLVL") == 0)
				{
					printf("************************************(30 env.c)\n");
				}
				if (ft_strcmp(current_env->name, "PWD") == 0)
				{
					printf("************************************(33 env.c)\n");
				}
				if (ft_strcmp(current_env->name, "OLDPWD") == 0)
				{
					printf("************************************(37 env.c)\n");
				}
			}
			
            if (current_env->status == 0)
            {
                printf("%s=%s\n", current_env->name, current_env->value);
            }
            current_env = current_env->next;
        }
        tmp_shell_level--;
    }
}
