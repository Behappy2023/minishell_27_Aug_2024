
#include "../minishell.h"


int ft_is_minishell(char *cmd, t_data *d)  //use
{
	char 	**sp_cmd;

	if(g%2==0)printf("	check_ft_is_minishell	(++9 builtin.c)\n");
	(void)d;
	sp_cmd = ft_split(cmd, ' ');
    if ( ft_strcmp(sp_cmd[0], "./minishell") == 0 )
    {
		ft_free_split(sp_cmd);
        return (1);
    }

	ft_free_split(sp_cmd);
    return (0);
}

// void	ft_exec_builtin_cd_exit(char *cmd, t_data *d)
// {
// 	(void)cmd;
// 	if(ft_strncmp(cmd, "cd", 2) == 0)
// 		ft_cd(cmd, d);
	
// 	else if(strncmp(cmd, "exit", 4) == 0)
// 		ft_exit(cmd, d);
// }


void	ft_exec_builtin(char *cmd, t_data *d, char *export_no_print)  //use
{
	(void)cmd;
	if(ft_strncmp(cmd, "cd", 2) == 0)
		ft_cd(cmd, d);

	if (ft_strncmp(cmd, "echo", 4) == 0)
		ft_echo(cmd, d);

	else if(strcmp(cmd, "env") == 0)
		ft_env(cmd, d);

	else if(strncmp(cmd, "exit", 4) == 0)
	{
		ft_exit(cmd, d);
		// if(g%2==0)printf("	after ft_exit.c (32 builtin.c)\n");
		
	}
	else if(ft_strncmp("export", cmd, 6) == 0)
	{	
		if (export_no_print)
		{
			if(g%2==0)printf("	export no print	(36 builtin.c)\n");
			ft_export_no_print(d->cmd, d);
		}
		else
		{
			if(g%2==0)printf("	export print	(41 builtin.c)\n");
			ft_export(cmd, d);
			if(g%2==0)printf("	export print	(43 builtin.c)\n");
		}
	}
	else if(strncmp(cmd, "pwd", 3) == 0)
		ft_pwd(cmd, d);
	
	else if (ft_strncmp(cmd, "unset", 5) == 0)
		ft_unset(cmd, d);

	else if (ft_strchr(cmd, '='))
		ft_export_secret(cmd, d->env_list, d);


	///////////////////////////////
				else if ( ft_strcmp(cmd, "chk") == 0)
				{
					while(d->env_list->name)
					{
						// if (d->env_list->status == 0)
						// {
						
							if (ft_strcmp(d->env_list->name ,"SHLVL") == 0)
								printf("************************************(102 builtin.c)\n");
							if (ft_strcmp(d->env_list->name ,"PWD") == 0)
								printf("************************************(106 builtin.c)\n");

							if (ft_strcmp(d->env_list->name ,"OLDPWD") == 0)
								printf("************************************(110 builtin.c)\n");

							printf("(status=  %d)  ",d->env_list->status);
							printf("(env_SHLVL=  %d) ",d->env_list->env_shlvl);
							printf("(high_level=  %d) ",d->env_list->high_level);

							printf("%s", d->env_list->name);
							if (d->env_list->value)
								printf("		= %s\n", d->env_list->value);
						// }
						d->env_list = d->env_list->next;
					}
				}	
	///////////////////////////////

	return;
}



int ft_is_builtin(char *cmd, t_data *d) //use
{
	(void)d;
	char 	**sp_cmd;
	if(g%2==0)printf("	welcome	builtin cmd = %s	(157 builtin.c)\n", cmd);

	sp_cmd = ft_split(cmd, ' '); 
	if(g%2==0)printf("	sp_cmd[0] = %s	(161 builtin.c)\n", sp_cmd[0]);

	// if (ft_strcmp(sp_cmd[0], "export") == 0 && sp_cmd[1])
	// {
	// 	ft_free_split(sp_cmd);
	// 	if(g%2==0)printf("	ft_is_builtin_set_1 ==>yes (export_parameter)	(144 builtin.c)\n");
    //     return (1);
	// }
    // else 

	if (
		ft_strcmp(sp_cmd[0], "cd"	) == 0 ||
		ft_strcmp(sp_cmd[0], "echo"	) == 0 ||
        ft_strcmp(sp_cmd[0], "env"	) == 0 ||
        ft_strcmp(sp_cmd[0], "exit"	) == 0 ||
        ft_strcmp(sp_cmd[0], "export") == 0 ||	//<===
        ft_strcmp(sp_cmd[0], "pwd"	) == 0 ||
        ft_strcmp(sp_cmd[0], "unset"	) == 0 ||
		ft_strchr(cmd, '=')
		)
    {
		if(g%2==0)printf("	(181 builtin.c)\n");

		ft_free_split(sp_cmd);
		if(g%2==0)printf("	ft_is_builtin = yes	(179 builtin.c)\n");
        return (1);
    }

	else if (ft_strcmp(cmd, "./minishell") == 0)
	{
		if(g%2==0)printf("	(189 builtin.c)\n");

		d->shell_level++;
		d->exit_stat = 0;
		ft_free_split(sp_cmd);
		if(g%3==0)printf("	d->exit_stat =%d	(166 builtin.c)\n",d->exit_stat);
		if(g%5==0)printf("	d->shell_level =%d	(167 builtin.c)\n",d->shell_level);
		  return (1);
	}
	///////////////////////////////

					if ( ft_strcmp(sp_cmd[0], "chk") == 0)
					{
						if(g%2==0)printf("	check  export secret(152 builtin.c)\n");
						return(1);
					}	
	///////////////////////////////


	if(g%2==0)printf("	(198 builtin.c)\n");
	ft_free_split(sp_cmd);
	if(g%2==0)printf("	ft_is_builtin_set_1 ==>no (cd unset export_parameter)	(172 builtin.c)\n");
    return (0);
}



int ft_is_builtin_for_set_status(char *cmd, t_data *d) //use
{
	(void)d;
	char 	**sp_cmd;
	if(g%2==0)printf("	welcome	builtin cmd = %s	(157 builtin.c)\n", cmd);

	sp_cmd = ft_split(cmd, ' '); 
	if(g%2==0)printf("	sp_cmd[0] = %s	(161 builtin.c)\n", sp_cmd[0]);

	// if (ft_strcmp(sp_cmd[0], "export") == 0 && sp_cmd[1])
	// {
	// 	ft_free_split(sp_cmd);
	// 	if(g%2==0)printf("	ft_is_builtin_set_1 ==>yes (export_parameter)	(144 builtin.c)\n");
    //     return (1);
	// }
    // else 

	if (
		ft_strcmp(sp_cmd[0], "cd"	) == 0 ||
		ft_strcmp(sp_cmd[0], "echo"	) == 0||
        ft_strcmp(sp_cmd[0], "env"	) == 0 ||
        ft_strcmp(sp_cmd[0], "exit"	) == 0 ||
        ft_strcmp(sp_cmd[0], "export") == 0 ||	//<===
        ft_strcmp(sp_cmd[0], "pwd"	) == 0 ||
        ft_strcmp(sp_cmd[0], "unset"	) == 0 ||
		ft_strchr(cmd, '=') ||
		ft_strchr(cmd, 'grep')

		)
    {
		if(g%2==0)printf("	(181 builtin.c)\n");

		ft_free_split(sp_cmd);
		if(g%2==0)printf("	ft_is_builtin = yes	(179 builtin.c)\n");
        return (1);
    }

	else if (ft_strcmp(cmd, "./minishell") == 0)
	{
		if(g%2==0)printf("	(189 builtin.c)\n");

		// d->shell_level++;
		// d->exit_stat = 0;
		ft_free_split(sp_cmd);
		// if(g%3==0)printf("	d->exit_stat =%d	(263 builtin.c)\n",d->exit_stat);
		// if(g%5==0)printf("	d->shell_level =%d	(264 builtin.c)\n",d->shell_level);
		  return (1);
	}
	///////////////////////////////

					if ( ft_strcmp(sp_cmd[0], "chk") == 0)
					{
						if(g%2==0)printf("	check  export secret(152 builtin.c)\n");
						return(1);
					}	
	///////////////////////////////


	if(g%2==0)printf("	(198 builtin.c)\n");
	ft_free_split(sp_cmd);
	if(g%2==0)printf("	ft_is_builtin_set_1 ==>no (cd unset export_parameter)	(172 builtin.c)\n");
    return (0);
}


int ft_is_builtin_set_1(char *cmd, t_data *d) //use
{
	char 	**sp_cmd;

	sp_cmd = ft_split(cmd, ' ');
	if (ft_strcmp(sp_cmd[0], "export") == 0 && sp_cmd[1]) // export have args
	{
		ft_free_split(sp_cmd);
		if(g%2==0)printf("	ft_is_builtin_set_1 ==>yes (export_parameter)	(144 builtin.c)\n");
        return (1);
	}
    else if (
		ft_strcmp(sp_cmd[0], "cd"	) == 0 ||
		// ft_strcmp(sp_cmd[0], "echo"	) == 0 ||
        // ft_strcmp(sp_cmd[0], "env"	) == 0 ||
        ft_strcmp(sp_cmd[0], "exit"	) == 0 ||
        // ft_strcmp(sp_cmd[0], "export") == 0 ||	//<===
        // ft_strcmp(sp_cmd[0], "pwd"	) == 0 ||
        ft_strcmp(sp_cmd[0], "unset"	) == 0 ||
		ft_strchr(cmd, '=')
		)
    {
		ft_free_split(sp_cmd);
		if(g%2==0)printf("	ft_is_builtin_set_1 ==>yes (cd unset)	(160 builtin.c)\n");
        return (1);
    }
	else if (ft_strcmp(d->cmd, "./minishell") == 0)
	{
		d->shell_level++;
		ft_free_split(sp_cmd);
		if(g%5==0)printf("	d->shell_level =%d	(314 builtin.c)\n",d->shell_level);
		  return (1);
	}

	ft_free_split(sp_cmd);
	if(g%2==0)printf("	ft_is_builtin_set_1 ==>no (cd unset export_parameter)	(172 builtin.c)\n");
    return (0);
}
