


#include "../minishell.h"


int ft_is_unset(char *cmd, t_data *d)
{
	char 	**sp_cmd;

	(void)d;
	sp_cmd = ft_split(cmd, ' ');
    if ( ft_strcmp(sp_cmd[0], "unset") == 0 )
    {
		ft_free_split(sp_cmd);
        return (1);
    }

	ft_free_split(sp_cmd);
    return (0);
}



void ft_unset_remove_node(t_env **env_list, const char *name)  // unset
{
    t_env *current = *env_list;
    t_env *previous = NULL;

    while (current != NULL) {
        if (strcmp(current->name, name) == 0) 
		{
            if (previous == NULL) 
			{
                *env_list = current->next;
            } else 
			{
                previous->next = current->next;
            }
            free(current->name);
            free(current->value);
            free(current);
            return;
        }
        previous = current;
        current = current->next;
    }
}



void	ft_unset(char *cmd, t_data *d)
{
	(void)cmd;
	(void)d;
	if(ft_strncmp(cmd, "unset", ft_strlen(cmd)) == 0)
	{
		if(g%2==0)printf("<===noting phone\n");
	}
	else
	{
		char *token = ft_strtoken(cmd, " ");
		token = ft_strtoken(NULL, " "); // ข้ามคำสั่ง 'unset'

		while (token != NULL) 
		{
			ft_unset_remove_node(&d->env_list, token);
     	   token = ft_strtoken(NULL, " ");
   		}

	}


	
}
