
#include "../minishell.h"

char *ft_export_strjoin_space(char const *s1, char const *s2)
{
    char    *str;
    size_t  len1;
    size_t  len2;

    if (!s1 || !s2)
        return (NULL);
    len1 = ft_strlen(s1);
    len2 = ft_strlen(s2);
    str = malloc(sizeof(char) * (len1 + len2 + 2));
    if (!str)
        return (NULL);
    ft_strcpy(str, s1) ;
    str[len1] = ' ';
    ft_strcpy(str + len1 + 1, s2);
    return (str);
}

void	ft_print_bash_export(char *sp_cmd, t_data *d)
{
	printf("bash: export: \'%s\': not a valid identifier\n",sp_cmd);
	d->exit_stat = 256;
}

int	ft_export_name_args_correct_2(char *cmd)
{
	int	i =0;

	if ((cmd[0] >= '0' && cmd[0] <= '9' ) || (cmd[0] == '=' ))
		return(1); //wrong
	while (cmd[i])
	{
		if (!(	('A' <= cmd[i] && cmd[i] <= 'Z') 
			|| 	('a' <= cmd[i] && cmd[i] <= 'z')
			|| 	('0' <= cmd[i] && cmd[i] <= '9')	
			||	('=' == cmd[i])))
			return (1);//wromg
		if ('=' == cmd[i])
			return (0);
		i++;
	}
	return (0);
}

////////////////
void ft_move_quote(char *str)
{
    int i = 0;
    int found_quote = 0;
    int found_equal = 0;

    // Step 1: ลบเครื่องหมาย " ตัวแรกที่เจอ
    while (str[i] != '\0')
    {
        if (str[i] == '"' && !found_quote)
        {
            // ข้ามเครื่องหมาย " ตัวแรกที่เจอ
            found_quote = 1;
            memmove(&str[i], &str[i + 1], strlen(str) - i);
        }
        else
            i++;
    }
    // Step 2: หาเครื่องหมาย = แล้วใส่เครื่องหมาย " หลัง =
    i = 0;
    while (str[i] != '\0')
    {
        if (str[i] == '=' && !found_equal)
        {
            // เพิ่มเครื่องหมาย " หลังจากเครื่องหมาย =
            found_equal = 1;
            int len = strlen(str);
            // ขยายขนาดสตริงเพื่อใส่เครื่องหมาย "
            str = realloc(str, len + 2);
            if (str == NULL)
                return;
            // ขยับสตริงหลังเครื่องหมาย = เพื่อใส่เครื่องหมาย "
            memmove(&str[i + 2], &str[i + 1], len - i + 1);
            str[i + 1] = '"';
        }
        i++;
    }
}
////////////////

char	*ft_export_name_args_correct(char *cmd, t_data *d)
{
	char **sp_cmd;
	char *cmd_after_check_num;
	char *cmd_temp;
	int	i;

	i = 0;
	cmd_temp = NULL;
	cmd_after_check_num = ft_strdup("");
	sp_cmd = ft_super_split(cmd, "");
	while (sp_cmd[i])
	{
		if (sp_cmd[i][0] == '\"')
			ft_move_quote(sp_cmd[i]); 					//<========
		if (ft_export_name_args_correct_2(sp_cmd[i]))
			ft_print_bash_export(sp_cmd[i], d);
		else
		{
			cmd_temp = ft_export_strjoin_space(cmd_after_check_num , sp_cmd[i]);
			free(cmd_after_check_num);
			cmd_after_check_num = cmd_temp;
		}
		free(sp_cmd[i]);
		i++;
	}
	free(sp_cmd);
	// printf("	79 token= %s\n", cmd_after_check_num);
	return(cmd_after_check_num);
}
