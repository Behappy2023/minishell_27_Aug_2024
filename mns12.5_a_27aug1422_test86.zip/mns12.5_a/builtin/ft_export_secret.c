

#include "../minishell.h"

/*
 gg=88 hh
hh: command not found
*/

/*
void	ft_export_secret_original(char *cmd, t_env *env_list)
{
	char	*equal_sign;
	char	*name;
	char	*value;
	t_env	*current;
	t_env	*last;
	t_env	*new_node;

	equal_sign = strchr(cmd, '=');
	if (ft_strchr(cmd, ' '))
	{
		printf("%s: command not found", ft_strchr(cmd, ' ') + 1);
		return ;
	}
	if (equal_sign == NULL)
	{
		fprintf(stderr, "Invalid command format. No '=' found.\n");
		return ;
	}
	*equal_sign = '\0'; // แยกชื่อและค่า
	name = cmd;
	value = equal_sign + 1;
	current = env_list;
	last = NULL;
	while (current != NULL)
	{
		if (strcmp(current->name, name) == 0)
		{
			// พบชื่อที่ตรงกันใน env_list ให้แทนที่ค่า value ใหม่
			free(current->value);
			current->value = strdup(value);
			*equal_sign = '='; // คืนค่า '=' ที่ถูกแยกออกไป
			return ;
		}
		last = current;
		current = current->next;
	}
	// ไม่พบชื่อที่ตรงกันใน env_list ให้เพิ่มโหนดใหม่
	new_node = malloc(sizeof(t_env));
	if (!new_node)
	{
		perror("malloc");
		*equal_sign = '='; // คืนค่า '=' ที่ถูกแยกออกไป
		return ;
	}
	new_node->name = strdup(name);
	new_node->value = strdup(value);
	new_node->status = 2;
	new_node->env_shlvl = d->shell_level; 	//<==add		
	new_node->high_level = 1;
	new_node->next = NULL;
	if (last != NULL)
	{
		last->next = new_node;
	}
	else
	{
		// ถ้า last เป็น NULL แปลว่า env_list ว่างเปล่า
		env_list = new_node;
	}
	*equal_sign = '='; // คืนค่า '=' ที่ถูกแยกออกไป
	// int status = 2;
	// printf("Status: %d\n", status); // สถานะเป็น 2 ตามที่กำหนด
}
*/

void ft_export_secret(char *cmd, t_env *env_list, t_data *d) 
{
    char *equal_sign;
    char *name;
    char *value;
    t_env *current;
    t_env *last;
    t_env *new_node;

    char *token = strtok(cmd, " ");
    while (token != NULL) 
	{
        equal_sign = strchr(token, '=');
        if (equal_sign == NULL) 
		{
            // fprintf(stderr, "Error: %s\n", token);
			printf("%s: command not found\n", token);
			return;
        }
        token = strtok(NULL, " ");
	}


    token = strtok(cmd, " ");
    while (token != NULL) 
	{
		equal_sign = strchr(token, '=');
        if (equal_sign == NULL) 
		{
            fprintf(stderr, "Error: %s\n", token);
        }
		else 
		{
            *equal_sign = '\0'; // แยกชื่อและค่า
            name = token;
            value = equal_sign + 1;
            current = env_list;
            last = NULL;

            while (current != NULL) {
                if (strcmp(current->name, name) == 0) {
                    // พบชื่อที่ตรงกันใน env_list ให้แทนที่ค่า value ใหม่
                    free(current->value);
                    current->value = strdup(value);
                    *equal_sign = '='; // คืนค่า '=' ที่ถูกแยกออกไป
                    break;
                }
                last = current;
                current = current->next;
            }

            if (current == NULL) {
                // ไม่พบชื่อที่ตรงกันใน env_list ให้เพิ่มโหนดใหม่
                new_node = malloc(sizeof(t_env));
                if (!new_node) {
                    perror("malloc");
                    *equal_sign = '='; // คืนค่า '=' ที่ถูกแยกออกไป
                    return;
                }
                new_node->name = strdup(name);
                new_node->value = strdup(value);
                new_node->status = 2;
				new_node->env_shlvl = d->shell_level; 	//<==add	
                new_node->next = NULL;
                if (last != NULL) {
                    last->next = new_node;
                } else {
                    // ถ้า last เป็น NULL แปลว่า env_list ว่างเปล่า
                    env_list = new_node;
                }
            }
            *equal_sign = '='; // คืนค่า '=' ที่ถูกแยกออกไป
        }
        token = strtok(NULL, " ");
    }
}
