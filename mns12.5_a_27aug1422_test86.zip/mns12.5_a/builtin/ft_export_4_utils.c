#include "../minishell.h"

char *ft_strtoken(char *str, const char *delim)
{
    static char *next_token = NULL;
    char *token_start;

    if (str != NULL) 
        next_token = str; 
	else if (next_token == NULL)
        return NULL; 
    while (*next_token && ft_strchr(delim, *next_token)) 
        next_token++;
    if (!*next_token) 
	{
        next_token = NULL;
        return NULL;
    }
    token_start = next_token;
    while (*next_token && !ft_strchr(delim, *next_token)) 
        next_token++;
    if (*next_token) 
	{
        *next_token = '\0';
        next_token++;
    }
    return (token_start);
}

char	*ft_strcpy(char *dst, const char *src)
{
	int	i;
	i = 0;
	while (src[i] != '\0')
	{
		dst[i] = src[i];
		i++;
	}
	dst[i] = '\0';
	return (dst);
}

char	*ft_strncpy(char *dst, const char *src, size_t n)
{
	size_t	i;
	i = 0;
	while (i < n && src[i] != '\0')
	{
		dst[i] = src[i];
		i++;
	}
	while (i < n)
	{
		dst[i] = '\0';
		i++;
	}
	return (dst);
}

void  ft_if_malloc_failed(void)
{
	printf("Memory allocation failed\n");
    exit(EXIT_FAILURE);
}
char *ft_trim_quotes(char *str)
{
    int len;
	char *original_str;
 	char *trimmed_str;

	len = ft_strlen(str);
    if (len >= 2 && str[0] == '"' && str[len - 1] == '"')
    {
        trimmed_str = (char *)malloc(len - 1);
        if (!trimmed_str)
			ft_if_malloc_failed();
        ft_strncpy(trimmed_str, str + 1, len - 2);
        trimmed_str[len - 2] = '\0';
        return (trimmed_str);
    }
    else
    {
        original_str = (char *)malloc(len + 1);
        if (!original_str)
			ft_if_malloc_failed();		 
        ft_strcpy(original_str, str);
        return (original_str);
    }
}
