

#include "../minishell.h"


/*
Test  26: ❌ export A- 
Test  30: ❌ export HELLO-=123 
Test  31: ❌ export = 
Test  32: ❌ export 123 
*/


// int ft_is_export(char *cmd, t_data *d)
// {
// 	char 	**sp_cmd;

// 	if(g%2==0)printf("	check_ft_is_export(18 export.c)\n");
// 	(void)d;
// 	sp_cmd = ft_split(cmd, ' ');
//     if ( ft_strcmp(sp_cmd[0], "export") == 0 )
//     {
// 		ft_free_split(sp_cmd);
//         return (1);
//     }

// 	ft_free_split(sp_cmd);
//     return (0);
// }


char *ft_strtok(char *str, const char *delim) 
{
    static char *next_token = NULL;

    if (str != NULL) 
        next_token = str; 
	else if (next_token == NULL)
        return NULL; 

    while (*next_token && ft_strchr(delim, *next_token)) 
        next_token++;

    if (!*next_token) 
	{
        next_token = NULL;
        return NULL;
    }

    char *token_start = next_token;
    while (*next_token && !ft_strchr(delim, *next_token)) 
        next_token++;

    if (*next_token) 
	{
        *next_token = '\0';
        next_token++;
    }

    return token_start;
}



void ft_export_insert_sort(t_env **sorted, t_env *new_node) 	//for export cmd
{
    if (*sorted == NULL || ft_strcmp((*sorted)->name, new_node->name) > 0)
    {
        new_node->next = *sorted;
        *sorted = new_node;
    }
    else
    {
        t_env *current = *sorted;
        while (current->next && ft_strcmp(current->next->name, new_node->name) <= 0)
        {
            current = current->next;
        }
        new_node->next = current->next;
        current->next = new_node;
    }
}


t_env *ft_export_sort_list(t_env *head)	//for export cmd
{
    t_env *sorted = NULL;
    t_env *current = head;
    while (current)
    {
        t_env *next = current->next;
        ft_export_insert_sort(&sorted, current);
        current = next;
    }
    return sorted;
}



char *ft_export_strjoin_space(char const *s1, char const *s2)
{
    char    *str;
    size_t  len1;
    size_t  len2;

    if (!s1 || !s2)
        return (NULL);
    len1 = strlen(s1);
    len2 = strlen(s2);
    str = malloc(sizeof(char) * (len1 + len2 + 2));
    if (!str)
        return (NULL);
    strcpy(str, s1);
    str[len1] = ' ';
    strcpy(str + len1 + 1, s2);
    return (str);
}


int	ft_export_name_parameter_correct_2(char *cmd)
{
	int	i =0;

	if ((cmd[0] >= '0' && cmd[0] <= '9' ) || (cmd[0] == '=' ))
		return(1); //wrong

	while (cmd[i])
	{
		if(g%2==0)		
			printf("	cmd[%d] = %c (125 export)\n", i, cmd[i]);

		// if (!(	('A' <= cmd[i] && cmd[i] <= 'Z') 
		// 	|| 	('a' <= cmd[i] && cmd[i] <= 'z')
		// 	|| 	('0' <= cmd[i] && cmd[i] <= '9')	
		// 	||	('=' == cmd[i])))
		// {
		// 	return (1);//wromg
		// }
		if ('=' == cmd[i])
			return (0);

		i++;
	}
	return (0);

}




char	*ft_export_name_parameter_correct(char *cmd, t_data *d)
{
	if(g%2==0)
		printf("\n	cmd =%s	(108 export.c)\n", cmd);


	char **sp_cmd;
	char *cmd_after_check_num = ft_strdup("");
	char *cmd_temp = NULL;
	// int	error_cmd_is_num = 0; 
	int	i;

	i = 0;
	sp_cmd = ft_split(cmd, ' ');
	// sp_cmd = ft_split_input(cmd, "");
	// sp_cmd = ft_super_split(cmd, "");


	if(g%2==0)
	{	
		while(sp_cmd[i])
		{
			// sp_cmd[i]= ft_trim_quotes(sp_cmd[i]);
			printf("	sp_cmd[%d]=%s	(160 export.c)\n",i, sp_cmd[i]);
			i++;
		}
		i = 0;
	}



	while (sp_cmd[i])
	{
		if(g%2==0)  printf("	sp_cmd[%d]=%s	(184 export.c)\n",i, sp_cmd[i]);
		sp_cmd[i]= ft_trim_quotes(sp_cmd[i]);
		if(g%2==0)  printf("	sp_cmd[%d]=%s	(188 export.c)\n\n",i, sp_cmd[i]);
	
		if(g%2==0)printf("	sp_cmd[%d]=%s	(121 export.c)\n", i, sp_cmd[i]);

		if (ft_export_name_parameter_correct_2(sp_cmd[i]))
		{
			printf("bash: export: \'%s\': not a valid identifier\n",sp_cmd[i]);
			d->exit_stat = 256;
		}
		else
		{
			cmd_temp = ft_export_strjoin_space(cmd_after_check_num , sp_cmd[i]);
			free(cmd_after_check_num);
			cmd_after_check_num = cmd_temp;
		}
		free(sp_cmd[i]);
		i++;
	}
	free(sp_cmd);

	if(g%2==0)printf("	cmd_after_check_num =%s (142 export.c)\n",cmd_after_check_num);

	return(cmd_after_check_num);
}


char	*ft_strncpy(char *dst, const char *src, size_t n)
{
	size_t	i;

	i = 0;
	while (i < n && src[i] != '\0')
	{
		dst[i] = src[i];
		i++;
	}
	while (i < n)
	{
		dst[i] = '\0';
		i++;
	}
	return (dst);
}

char	*ft_strcpy(char *dst, const char *src)
{
	int	i;

	i = 0;
	while (src[i] != '\0')
	{
		dst[i] = src[i];
		i++;
	}
	dst[i] = '\0';  // อย่าลืมเติม null-terminator ลงในตัวแปรปลายทาง
	return (dst);
}



char *ft_trim_quotes(char *str)
{
    int len = ft_strlen(str);
    if (len >= 2 && str[0] == '"' && str[len - 1] == '"')
    {
        char *trimmed_str = (char *)malloc(len - 1);
        if (!trimmed_str)
        {
            fprintf(stderr, "Memory allocation failed\n");
            exit(EXIT_FAILURE);
        }
        ft_strncpy(trimmed_str, str + 1, len - 2);
        trimmed_str[len - 2] = '\0';
        return trimmed_str;
    }
    else
    {
        char *original_str = (char *)malloc(len + 1);
        if (!original_str)
        {
            fprintf(stderr, "Memory allocation failed\n");
            exit(EXIT_FAILURE);
        }
        ft_strcpy(original_str, str);
        return original_str;
    }
}




void ft_export_have_parameter(char *cmd, t_env **env_list, t_data *d) 
{ 
	t_env 	*current;
	char	*name;
	char 	*value;
	char 	*token; 
	(void)token;
	(void)value;
	(void)name;
	(void)current;
	(void)env_list;

	if(g%2==0)printf("	cmd=%s	(230 export.c)\n", cmd);

	cmd = ft_export_name_parameter_correct(cmd, d);

    token = ft_strtok(cmd, " "); 
	if(g%2==0)printf("	token=%s	(235 export.c)\n", token);

	


    while (token != NULL) 
	{
        char *equal_sign = ft_strchr(token, '=');
        if (equal_sign != NULL) 
		{
            *equal_sign = '\0';
            name = token;
			/////////////////////////////
			// if (ft_strchr(  (equal_sign + 1), '"') == 0)
			// 	value = equal_sign + 2;
			// else
				// printf("1==%s\n", value);
            	value = equal_sign + 1;
				// printf("2==%s\n", value);

				value = ft_trim_quotes(value);
				// printf("3==%s\n", value);


            // เช็คว่ามี name ใน env_list หรือไม่
            current = *env_list;
            while (current != NULL) 
			{
                if (ft_strcmp(current->name, name) == 0)
				{
					if ( current->env_shlvl == d->shell_level)
					{
						if(g%2==0)printf("	add export (218 export.c)\n");
						free(current->value); // ลบค่า value เก่า
						current->value = ft_strdup(value); // กำหนดค่า value ใหม่
						current->status = 0; //<==addddddddddddddddd   type env have
						current->high_level = 1;
						break;
					}
					// if ( current->env_shlvl < d->shell_level)
					// {
					// 	current->high_level = 0;
					// 	// break;
					// }

                    // break;
                }

                current = current->next;
            }
            if (current == NULL) 
			{
                // ถ้าไม่พบ name ใน env_list ให้เพิ่มเข้าไปใหม่
                t_env *new_node = malloc(sizeof(t_env));
                new_node->name = ft_strdup(name);
				if (value)
				{
					new_node->value = ft_strdup(value);
					new_node->status = 0; 					//<==add			
					new_node->env_shlvl = d->shell_level; 	//<==add		
					new_node->high_level = 1;
				}
				else
				{
					new_node->value = ft_strdup(value);
					new_node->status = 1; 					//<==add		
					new_node->env_shlvl = d->shell_level; 	//<==add		
					new_node->high_level = 1;

				}

				new_node->next = NULL;

                // เพิ่มโหนดใหม่เข้าไปที่ท้าย env_list
                if (*env_list == NULL) 
				{
                    *env_list = new_node;
                } 
				else 
				{
                    current = *env_list;
                    while (current->next != NULL) 
					{
                        current = current->next;
                    }
                    current->next = new_node;
                }
            }
			free(value);
        } 
		else 
		{
            // ไม่มีเครื่องหมาย = แสดงว่าเป็นตัวแปร name เท่านั้น
            // เช็คว่ามี name ใน env_list หรือไม่ (ในกรณีนี้ value จะเป็น NULL)
            t_env *current = *env_list;
            while (current != NULL) 
			{
                if (strcmp(current->name, token) == 0) 
				{
                    break; // ไม่ต้องทำอะไรเพราะ name นี้มีอยู่แล้ว
                }
                current = current->next;
            }
            if (current == NULL) 
			{
                // ถ้าไม่พบ name ใน env_list ให้เพิ่มเข้าไปใหม่ (value เป็น NULL)
                t_env *new_node = malloc(sizeof(t_env));
                new_node->name = ft_strdup(token);
                new_node->value = ft_strdup("");
				new_node->status = 1;
				new_node->env_shlvl = d->shell_level; 	//<==add		
				new_node->high_level = 1;
                new_node->next = NULL;

                // เพิ่มโหนดใหม่เข้าไปที่ท้าย env_list
                if (*env_list == NULL) 
				{
                    *env_list = new_node;
                } 
				else 
				{
                    current = *env_list;
                    while (current->next != NULL) 
					{
                        current = current->next;
                    }
                    current->next = new_node;
                }
            }
        }
        token = ft_strtok(NULL, " "); // ไปตัด token ถัดไป
    }


	free(cmd);
	// free(token);


}


void	ft_export(char *cmd, t_data *d)
{
	(void)cmd;
	t_env	*tmp = d->env_list;

	if(ft_strncmp(cmd, "export", ft_strlen(cmd)) == 0)
	{
		if(g%2==0)printf("	export (284 export.c)\n");
		d->env_list = tmp;
		d->export_list = ft_export_sort_list(d->env_list);
		// tmp = ft_export_sort_list(d->env_list);
		while(d->export_list->name)
		{

			if (ft_strcmp(d->export_list->name ,"PWD") == 0)
				d->export_list->value = d->pwd;
			if (ft_strcmp(d->export_list->name ,"OLDPWD") == 0)
				d->export_list->value = d->old_pwd;

			if (ft_strcmp(d->export_list->name ,"SHLVL") == 0)
				d->export_list->value = ft_itoa(d->shell_level);


			if 	(ft_strcmp(d->export_list->name, "SHLVL") == 0
			|| (ft_strcmp(d->export_list->name, "USER") == 0)
			|| (ft_strcmp(d->export_list->name, "HOME") == 0)
			|| (ft_strcmp(d->export_list->name ,"PWD") == 0)
			|| (ft_strcmp(d->export_list->name ,"OLDPWD") == 0)	)
				{
					printf("************************************(305 export.c)\n");
					// printf("declare -x %s", d->export_list->name);
					// printf("=\"%s\"", d->export_list->value);
					// printf("\n");
				}

			printf("declare -x %s", d->export_list->name);
			printf("=\"%s\"", d->export_list->value);
			printf("\n");

			if(!d->export_list->next)
				break;
			d->export_list = d->export_list->next;
		}

		// d->export_list = tmp;

	}
	// else
	// {
	// 	if(g%2==0)printf("	export have parameter(318 export.c)\n");
	// 	ft_export_have_parameter(cmd+7, &d->env_list, d);
	// }
}



int ft_is_export(char *cmd, t_data *d)
{
	char 	**sp_cmd;

	(void)d;
	sp_cmd = ft_split(cmd, ' ');
    if ( ft_strcmp(sp_cmd[0], "export") == 0 )
    {
		ft_free_split(sp_cmd);
        return (1);
    }

	if (ft_strchr(sp_cmd[0], '='))
		// return(1);
		ft_export_secret(cmd, d->env_list, d);


	ft_free_split(sp_cmd);
    return (0);
}



void	ft_export_no_print(char *cmd, t_data *d)
{
	(void)cmd;
	(void)d;


	if(ft_strncmp(cmd, "export", ft_strlen(cmd)) == 0)
	{
		if(g%2==0)printf("	export no parameter (347 export.c)\n");
	}
	else
	{
		if(g%2==0)printf("	export have parameter(412 export.c)\n");
		ft_export_have_parameter(cmd+7, &d->env_list, d);

	}
}
