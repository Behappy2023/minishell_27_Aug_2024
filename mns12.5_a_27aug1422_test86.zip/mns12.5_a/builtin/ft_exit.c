
/*

exit 9223372036854775807
exit -9223372036854775808

*/


#include "../minishell.h"


int ft_is_exit(char *cmd, t_data *d)
{
	char 	**sp_cmd;

	if(g%2==0)printf("	check_ft_is_exit(27 exit.c)\n");
	(void)d;
	sp_cmd = ft_split(cmd, ' ');
    if ( ft_strcmp(sp_cmd[0], "exit") == 0 )
    {
		ft_free_split(sp_cmd);
        return (1);
    }

	ft_free_split(sp_cmd);
    return (0);
}


int ft_str_is_one(const char *str) 
{

	if(g%2==0)printf("	str_one str= %s	(62 exit.c)\n", str);
	int i = 0;

	if (str[i+1] == '\'' ||str[i+1] == '\"')
	{
		if (str[i] == '+' ||str[i] == '-')
			i++;
	}

	if (str[i] == '\'' ||str[i] == '\"')
		i++;

	if (str[i] == '0')
	{
		if (g%2==0)printf("	str[%d] = %c	str is one (66 exit.c)\n", i, str[i]);
		return(ft_atoi(str+i));
	}
	else
	{
		if (g%2==0)printf("	str[%d] = %c	str is one (71 exit.c)\n", i, str[i]);
		return(1);
	}
}



long long int ft_str_is_zero(const char *str) 
{
	if(g%2==0)printf("	str_zero str= %s	(89 exit.c)\n", str);
	long long int nb;
	int i = 0;
	int	neg =0;

	if (str[i+1] == '\'' ||str[i+1] == '\"')
	{
		if (str[i] == '-')
			neg = 1;
		if (str[i] == '+' ||str[i] == '-')
			i++;
	}

	if (str[i] == '\'' ||str[i] == '\"')
		i++;

	nb = ft_atoi(str + i); 


	// if ( (nb >= -256 ) && (neg <= -1) )///////////////////
	if ( (nb >= -256 ) && (neg == 1) )
	{
		nb = nb * -1;
		nb = nb + 256;	
		// nb = nb * -1 + 256;	

	}
	if (g%2==0)printf("	nb = %lld	str is zero (105 exit.c)<====\n", nb);
	return(nb);

}


void	ft_exit(char *cmd, t_data *d)
{
	(void)cmd;
	char	**sp_cmd;
	int		exit_status_no_free;

	if(g%3==0)printf("	Welcome to ft_exit  d->exit_status (now)=%d	(43 exit.c)\n", d->exit_stat);
	sp_cmd = ft_split(cmd, ' ');
	
/*
EXIT CODE
TEXT ERROR
SHL LV
FREE
*/		
	if (sp_cmd[1] == NULL)
	{
		if(g%2==0)printf("	debug	(138 exit.c)\n");
		
		ft_free_split(sp_cmd);
		// if (sp_cmd[1])
		// 	d->exit_stat = ft_atoi(sp_cmd[1]) * 256;
		printf("exit\n");
		d->shell_level--;
		if (g%2==0) printf("	d->exit_stat = %d	(118 exit.c)\n", d->exit_stat);
		if (g%2==0) printf("	d->shell_level = %d	(118 exit.c)\n", d->shell_level);
		if (d->shell_level < 1 )
		{

			exit_status_no_free = d->exit_stat / 256;
			ft_free_system(d);
			ft_free_system_2(d);
		/*
			rl_clear_history();
			// // ft_free_set_start(d);
			free(d->word_real);				// ft_free_set_start
			free(d->word_tmp );				// ft_free_set_start
			ft_env_free_list(d->env_list);	// ft_free_set_start
			// exit_status_no_free = d->exit_status;
			free(d);
		*/
			if(g%3==0)printf("\033[0;31m	Real exit=%d\033[0m (156 exit.c)\n",exit_status_no_free);
			exit(exit_status_no_free);

			// exit(d->exit_stat);

		}
		return;

	}

	long long int	nb;
	int sp_cmd1_is_nb_sure = 1;
	nb = ft_str_is_zero(sp_cmd[1] );
	nb = nb % 256;
	if (g%2==0)printf("	nb = %lld 	(165 exit.c)<====\n",nb);	


	if (g%2==0)printf("	==chk str== 	(196 exit.c)\n");	

	if( (ft_str_is_one(sp_cmd[1])) && !ft_str_is_zero(sp_cmd[1] ))
	{		
		if (g%2==0)printf("	in loop str_is_one ,str_is_zero	(198 exit.c)\n");	
		if (g%2==0)printf("	str_one=%d	!str_zero=%d\n", ft_str_is_one(sp_cmd[1]) ,!ft_str_is_zero(sp_cmd[1]) );
		sp_cmd1_is_nb_sure = 0;
	}


	if (sp_cmd1_is_nb_sure == 1) 
	{

		if(g%2==0)printf("	sp_cmd1_is_nb_sure == 1	(209 exit.c)\n");

		if (sp_cmd[2])
		{
			ft_free_split(sp_cmd);
			d->exit_stat = 256;
			if(g%2==0)printf("	debug	(47 exit.c)\n");
			printf("exit\nbash: exit: too many arguments\n");
			// d->shell_level--;
		}
		else
		{
			if(g%3==0)printf("	multi d->exit = %d	nb = %lld (176 exit.c)<====\n\n\n", d->exit_stat, nb);
			d->exit_stat = nb * 256;
			if(g%3==0)printf("	d->exit = %d	nb = %lld (178 exit.c)<====\n\n\n", d->exit_stat, nb);

			ft_free_split(sp_cmd);
			printf("exit\n");
			d->shell_level--;
			if (d->shell_level < 1 )
			{				
				ft_free_system(d);
				rl_clear_history();
				// // ft_free_set_start(d);
				free(d->word_real);				// ft_free_set_start
				free(d->word_tmp );				// ft_free_set_start
				ft_env_free_list(d->env_list);	// ft_free_set_start

				exit_status_no_free = d->exit_stat / 256;
				free(d);
		
				if(g%3==0)printf("\033[0;31m	Real exit=%d\033[0m (195 exit.c)\n",exit_status_no_free);
				exit(exit_status_no_free);
			}
		}

	}

	else if (sp_cmd1_is_nb_sure == 0) 
	{
		if(g%2==0)printf("	sp_cmd1_is_nb_sure == 0	(175 exit.c)\n");

		d->exit_stat = 512;
		printf("exit\n");
		printf("bash: exit: %s: numeric argument required\n", sp_cmd[1]);
		ft_free_split(sp_cmd);
		d->shell_level--;
		if (d->shell_level < 1 )
		{			
			ft_free_system(d);
			rl_clear_history();
			// // ft_free_set_start(d);
			free(d->word_real);				// ft_free_set_start
			free(d->word_tmp );				// ft_free_set_start
			ft_env_free_list(d->env_list);	// ft_free_set_start
			exit_status_no_free = d->exit_stat / 256;
			free(d);
	
			if(g%3==0)printf("\033[0;31m	Real exit=%d\033[0m (220 exit.c)\n",exit_status_no_free);
			exit(exit_status_no_free);
		}	
	}

	
}
