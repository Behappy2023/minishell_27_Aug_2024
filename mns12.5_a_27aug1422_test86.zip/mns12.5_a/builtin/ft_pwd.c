
#include "../minishell.h"

void	ft_pwd(char *cmd, t_data *d)
{
	(void)cmd;

	// if (ft_strcmp(cmd, "pwd") == 0)
	// {

		if(g%2==0)
		{
			printf("d->pwd	= %s\n",d->pwd);
			getcwd(d->pwd, 1024);
			printf("getcwd	= %s\n",d->pwd);
		}

		getcwd(d->pwd, 1024);
		printf("%s\n",d->pwd);

	// }	
}
