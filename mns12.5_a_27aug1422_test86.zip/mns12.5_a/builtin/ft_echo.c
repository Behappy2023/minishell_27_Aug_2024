

#include "../minishell.h"

/*
							x				x
echo  $USER 	 "$USER"  "'$USER'"		"a '$USER' b"  	'$USER'  '"$USER"'  
	 kdanchal 	kdanchal  'kdanchal'	 a 'kdanchal b   $USER    "$USER"

*/

int ft_is_echo(char *cmd, t_data *d)
{
	char 	**sp_cmd;

	if(g%2==0)printf("	check_ft_is_echo(17 echo.c)\n");
	(void)d;
	sp_cmd = ft_split(cmd, ' ');
    if ( ft_strcmp(sp_cmd[0], "echo") == 0 )
    {
		ft_free_split(sp_cmd);
        return (1);
    }

	ft_free_split(sp_cmd);
    return (0);
}

char *ft_echo_get_env_var_value(t_env *env_list, const char *var, t_data *d) 
{
    t_env	*current;
	int		tmp_shell_level;
	tmp_shell_level = d->shell_level;
	
	while (tmp_shell_level)
	{
		current = env_list;
		while (current) 
		{
			if (ft_strcmp(current->name, var) == 0 && current->env_shlvl == tmp_shell_level) 
			{
				return current->value;
			}
			current = current->next;
		}
		tmp_shell_level--;
	}
    return NULL;
}

char *ft_echo_dollar(char *cmd, t_data *d) 
{
	// if (*cmd == ' ')
	// {
	// 	printf("aaa");
    //     return cmd;
		
	// }
	// else 
	if (*cmd == '?')
	{
		d->exit_stat = d->exit_stat / 256;
        printf("%d", d->exit_stat);
        d->exit_stat = 0;
        return cmd + 1;
    } 
	else if ( (*cmd == ' ') || !(*cmd) || (*cmd == '"'))
	{
		printf("$");
        return cmd;

	} 

	else 
	{
        char var_name[256];
        int i = 0;
        while (*cmd && (isalnum(*cmd) || *cmd == '_')) 
		{
            var_name[i++] = *cmd++;
        }
        var_name[i] = '\0';
        char *value = ft_echo_get_env_var_value(d->env_list, var_name, d);
        if (value) 
		{
            printf("%s", value);
        }
		// else
		// {
        //     printf("$");
		// }
        return cmd;
    }
}

void ft_echo(char *cmd, t_data *d) 
{
    int have_flag_n = 0;

    cmd += 4; // Skip the "echo" part
    while (*cmd == ' ') 
	{
        cmd++; // Skip leading spaces
    }

	if (ft_strcmp(cmd, "-n") == 0 )
		return;

    if (*cmd == '-' && *(cmd + 1) == 'n' && *(cmd + 2) == ' ') 
	{
        have_flag_n = 1;
        cmd += 3;
    }

    while (*cmd == ' ') 
	{
        cmd++; // Skip leading spaces
    }

    int in_single_quotes = 0;
    int in_double_quotes = 0;


	while (*cmd) 
	{
		if (*cmd == '\'') 
		{
			in_single_quotes = !in_single_quotes;
			cmd++; // Skip the single quote
			if (in_single_quotes) 
			{
				while (*cmd && *cmd != '\'') 
				{
					putchar(*cmd++);
				}
				if (*cmd == '\'') 
				{
					in_single_quotes = 0;
					cmd++; // Skip the closing single quote
				}
			}
		} 
		else if (*cmd == '\"') 
		{
			in_double_quotes = !in_double_quotes;
			cmd++; // Skip the double quote
			if (in_double_quotes) {
				while (*cmd && *cmd != '\"') 
				{
					if (*cmd == '$') {
						cmd = ft_echo_dollar(cmd + 1, d);
					} else {
						putchar(*cmd++);
					}
				}
				if (*cmd == '\"') 
				{
					in_double_quotes = 0;
					cmd++; // Skip the closing double quote
				}
			}
		}
		// else if (*cmd == '$' && !in_single_quotes && (*(cmd + 1) == ' '))
		// else if ( (ft_strncmp(cmd, "$", 1) == 0))
		// {
		// 	printf("aaa");
		// 	// return cmd;
		// }
		else if (*cmd == '$' && !in_single_quotes) 
		{
			cmd = ft_echo_dollar(cmd + 1, d);
		} 
		else 
		{
			putchar(*cmd);
			cmd++;
		}
	}

    if (!have_flag_n) 
	{
        printf("\n");
    }
}
