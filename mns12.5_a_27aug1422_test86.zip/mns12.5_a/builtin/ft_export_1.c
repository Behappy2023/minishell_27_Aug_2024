

#include "../minishell.h"

void ft_export_have_args(char *cmd, t_env **env_list, t_data *d)
{ 
	char 	**token; 
    char    *equal_sign;
    int     i;

    i = 0;
	cmd = ft_export_name_args_correct(cmd, d);
    token = ft_super_split(cmd, ""); 
    while (token[i] != NULL) 
	{
        equal_sign = ft_strchr(token[i], '=');
        if (equal_sign != NULL) 
            ft_have_equal_sign(token[i], equal_sign, d, env_list);	 
		else
            ft_no_equal_sign(token[i],env_list,d);
        i++;
    }
	free(cmd);
}

void ft_export_insert_sort(t_env **sorted, t_env *new_node)
{
    if (*sorted == NULL || ft_strcmp((*sorted)->name, new_node->name) > 0)
    {
        new_node->next = *sorted;
        *sorted = new_node;
    }
    else
    {
        t_env *current = *sorted;
        while (current->next && ft_strcmp(current->next->name, new_node->name) <= 0)
        {
            current = current->next;
        }
        new_node->next = current->next;
        current->next = new_node;
    }
}

t_env *ft_export_sort_list(t_env *head)
{
    t_env *sorted = NULL;
    t_env *current = head;
    while (current)
    {
        t_env *next = current->next;
        ft_export_insert_sort(&sorted, current);
        current = next;
    }
    return (sorted);
}

void	ft_export(char *cmd, t_data *d)
{
	t_env	*tmp = d->env_list;

	if(ft_strncmp(cmd, "export", ft_strlen(cmd)) == 0)
	{
		d->env_list = tmp;
		d->export_list = ft_export_sort_list(d->env_list);
		while(d->export_list->name)
		{
			if (ft_strcmp(d->export_list->name ,"PWD") == 0)
				d->export_list->value = d->pwd;
			if (ft_strcmp(d->export_list->name ,"OLDPWD") == 0)
				d->export_list->value = d->old_pwd;
			if (ft_strcmp(d->export_list->name ,"SHLVL") == 0)
				d->export_list->value = ft_itoa(d->shell_level);
			printf("declare -x %s", d->export_list->name);
			printf("=\"%s\"", d->export_list->value);
			printf("\n");
			if(!d->export_list->next)
				break;
			d->export_list = d->export_list->next;
		}
	}
	else
		ft_export_have_args(cmd+7, &d->env_list, d);
}




int ft_is_export(char *cmd, t_data *d)
{
	char 	**sp_cmd;

	(void)d;
	sp_cmd = ft_split(cmd, ' ');
    if ( ft_strcmp(sp_cmd[0], "export") == 0 )
    {
		ft_free_split(sp_cmd);
        return (1);
    }
	if (ft_strchr(sp_cmd[0], '='))
		ft_export_secret(cmd, d->env_list, d);
	ft_free_split(sp_cmd);
    return (0);
}

void	ft_export_no_print(char *cmd, t_data *d)
{
	if(ft_strncmp(cmd, "export", ft_strlen(cmd)) == 0)
	{
		if(g%2==0)printf("	export no parameter (347 export.c)\n");
	}
	else
	{
		if(g%2==0)printf("	export have parameter(412 export.c)\n");
		ft_export_have_args(cmd+7, &d->env_list, d);
	}
}
