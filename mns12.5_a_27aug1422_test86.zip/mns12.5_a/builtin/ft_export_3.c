
#include "../minishell.h"

void ft_if_current_empty2(t_env **env_list, char *token, t_env *current, t_data *d)
{
    t_env *new_node;

    new_node = malloc(sizeof(t_env));
    new_node->name = ft_strdup(token);
    new_node->value = ft_strdup("");
    new_node->status = 1;
    new_node->env_shlvl = d->shell_level;
    new_node->next = NULL;
    if (*env_list == NULL) 
        *env_list = new_node;
    else 
    {
        current = *env_list;
        while (current->next != NULL) 
        {
            current = current->next;
        }
        current->next = new_node;
    }
}

void    ft_no_equal_sign(char *token,t_env **env_list,t_data *d)
{
    t_env *current;

    current = *env_list;
    while (current != NULL) 
	{
        if (ft_strcmp(current->name, token) == 0) 
                break;
        current = current->next;
    }
    if (current == NULL)
    {
        ft_if_current_empty2(env_list,token,current,d);
    }
}

void ft_current_empty1(t_env *current, char *name, char *value,t_data *d, t_env **env_list)
{
    t_env *new_node;
    
    new_node = malloc(sizeof(t_env));
    new_node->name = ft_strdup(name);
	new_node->value = ft_strdup(value);
	new_node->status = 0;			
	new_node->env_shlvl = d->shell_level;		
	new_node->next = NULL;
    if (*env_list == NULL) 
        *env_list = new_node;
	else 
	{
        current = *env_list;
        while (current->next != NULL) 
            current = current->next;
        current->next = new_node;
    }
}

void ft_have_equal_sign(char *token, char *equal_sign, t_data *d, t_env **env_list)
{
    t_env 	*current;
	char	*name;
	char 	*value;

    *equal_sign = '\0';
    name = token;
    value = equal_sign + 1;
	value = ft_trim_quotes(value);
    current = *env_list;
    while (current != NULL) 
	{
        if( (ft_strcmp(current->name, name) == 0) && ( current->env_shlvl == d->shell_level) )
		{
				free(current->value);
				current->value = ft_strdup(value);
				current->status = 0;
				break;
        }
         current = current->next;
    }
    if(current == NULL) 
        ft_current_empty1(current, name,value,d,env_list);
    free(value);
}
