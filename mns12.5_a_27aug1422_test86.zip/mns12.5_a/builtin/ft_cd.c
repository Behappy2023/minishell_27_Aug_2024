


#include "../minishell.h"

void	ft_cd(char *cmd, t_data *d)
{
	(void)cmd;
	if(g%2==0)printf("	welcome CD mode cmd = %s	(9 cd.c)\n", cmd);

		// if(ft_strncmp( "cd", cmd, ft_strlen(cmd)) == 0)
		if(ft_strcmp( "cd", cmd) == 0)
		{
			if(g%2==0)printf("	go home	(14 cd.c)\n");
			ft_strlcpy(d->old_pwd ,d->pwd, ft_strlen(d->pwd));
			chdir("/home/kdanchal");
			getcwd(d->pwd, 1024);
			if(g%2==0)printf("	now=%s		(18 cd.c\n", d->pwd);
			if(g%2==0)printf("	old=%s		(19 cd.c\n", d->old_pwd);
		}
		else if(ft_strncmp(cmd, "cd ", 3) == 0)
		{
			char **sp_cmd = ft_split(cmd, ' ');
			// int	i = 0;
			// while (sp_cmd[i])
			// {
			// 	printf("	%s\n", sp_cmd[i]);
			// 	i++;
			// }
			// i = 0;

			if (sp_cmd[2])
			{
				printf("bash: cd: too many arguments\n");
				d->exit_stat = 256;
			}
			else
			{
				if (sp_cmd[1][0] == '$')
				{
					char var_name[256];
					int i = 0;
					while(sp_cmd[1][i + 1])
					{
						var_name[i] = sp_cmd[1][i + 1];
						if(g%2==0)	printf("	var_name[i] = sp_cmd[1][i + 1] = %s	(73 cd.c)\n", var_name);
						i++;
						
					}
					var_name[i] = '\0';
					char *value = ft_echo_get_env_var_value(d->env_list, var_name, d);
					(void) value;
					if (value) 
					{
						if(g%2==0)printf("	value = %s	(91 cd.c)\n", value);
						if (chdir(value) == -1)
							d->exit_stat = 256;

						ft_strlcpy(d->old_pwd ,d->pwd, ft_strlen(d->pwd)+1);
						getcwd(d->pwd, 1024);
						if(g%2==0)printf("	now=%s	(99 cd.c)\n", d->pwd);
						if(g%2==0)printf("	old=%s	(100 cd.c)\n", d->old_pwd);




						char tmp_pwd[1024];
						if(g%2==0)printf("	check\n");
						if(g%2==0)printf("	getcwd =%s	(69 cd.c)\n",getcwd(tmp_pwd, 1024));
						if(g%2==0)printf("	d->old_pwd =%s	(70 cd.c)\n",d->old_pwd);

						if ( (ft_strcmp ( getcwd(tmp_pwd, 1024), d->old_pwd) == 0)
						&& ( ft_strcmp (sp_cmd[1], "$PWD") != 0) )
						{
							printf("bash: cd: %s: No such file or directory	(75 cd.c)\n", value);
						}



						return;
					}
					else
					{
						printf("	$ no value	(84 cd.c)\n");
						if(g%2==0)printf("	go home	(85 cd.c)\n");
						ft_strlcpy(d->old_pwd ,d->pwd, ft_strlen(d->pwd));
						chdir("/home/kdanchal");
						getcwd(d->pwd, 1024);
						if(g%2==0)printf("	now=%s		(89 cd.c\n", d->pwd);
						if(g%2==0)printf("	old=%s		(90 cd.c\n", d->old_pwd);
						return;
					}
				}

				else
				{
					if (chdir(sp_cmd[1]) == -1)
						d->exit_stat = 256;

					ft_strlcpy(d->old_pwd ,d->pwd, ft_strlen(d->pwd)+1);
					getcwd(d->pwd, 1024);

					if(g%2==0)printf("	now=%s	(123 cd.c)\n", d->pwd);
					if(g%2==0)printf("	old=%s	(124 cd.c)\n", d->old_pwd);
				}
/*
				while(d->env_list->name)  // update PWD OLDPWD (env) in export
				{
					if (ft_strncmp(d->env_list->name, "PWD=", 4) == 0)
						d->env_list->value = d->pwd;
					if (ft_strncmp(d->env_list->name, "OLDPWD=", 7) == 0)
						d->env_list->value = d->old_pwd;
					d->env_list = d->env_list->next;
				}
*/
				char tmp_pwd[1024];
				if(g%2==0)printf("	check\n");
				if(g%2==0)printf("	getcwd =%s	(109 cd.c)\n",getcwd(tmp_pwd, 1024));
				if(g%2==0)printf("	d->old_pwd =%s	(110 cd.c)\n",d->old_pwd);

				if ( (ft_strcmp ( getcwd(tmp_pwd, 1024), d->old_pwd) == 0)
				&& ( ft_strcmp (sp_cmd[1], "$PWD") != 0) )
				{
					printf("bash: cd: %s: No such file or directory\n", sp_cmd[1]);
				}
			}
			ft_free_split(sp_cmd);
		}
}
